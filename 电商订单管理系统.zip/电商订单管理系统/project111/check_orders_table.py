import mysql.connector
from mysql.connector import Error

try:
    # 使用正确的数据库连接参数
    conn = mysql.connector.connect(
        host='127.0.0.1',
        port=3306,
        user='root',
        password='1975819cjn',
        database='ecommerce_db'
    )
    
    if conn.is_connected():
        cursor = conn.cursor()
        
        # 显示orders表结构
        print("Orders table structure:")
        print("-" * 60)
        cursor.execute('DESCRIBE orders')
        
        for row in cursor.fetchall():
            print(f"{row[0]}: {row[1]} (Null: {row[2]}, Key: {row[3]})")
        
        # 显示users表结构
        print("\nUsers table structure:")
        print("-" * 60)
        cursor.execute('DESCRIBE users')
        
        for row in cursor.fetchall():
            print(f"{row[0]}: {row[1]} (Null: {row[2]}, Key: {row[3]})")
        
        # 显示一条订单示例数据
        print("\nSample order data:")
        print("-" * 60)
        cursor.execute('SELECT * FROM orders LIMIT 1')
        order = cursor.fetchone()
        if order:
            cursor.execute('DESCRIBE orders')
            columns = [desc[0] for desc in cursor.description]
            for i, value in enumerate(order):
                print(f"  {columns[i]}: {value}")
        
        cursor.close()
        conn.close()
        print("\n-" * 60)
        print("Connection closed.")

except Error as e:
    print(f"Error: {e}")