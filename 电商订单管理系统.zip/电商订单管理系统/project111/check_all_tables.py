import mysql.connector
from mysql.connector import Error
import sys

# 配置数据库连接信息
db_configs = [
    {
        "user": "root",
        "password": "1975819cjn",
        "host": "127.0.0.1",
        "port": 3306,
        "database": "ecommerce_db"
    }
]

def create_connection():
    """创建数据库连接"""
    for config in db_configs:
        try:
            connection = mysql.connector.connect(**config)
            if connection.is_connected():
                print(f"成功连接到数据库! 使用配置: {config['user']}@localhost")
                return connection
        except Error as e:
            print(f"使用配置 {config['user']} 连接失败: {e}")
    return None

def check_database_tables():
    """检查数据库中的所有表和结构"""
    connection = create_connection()
    if not connection:
        print("无法连接到数据库")
        sys.exit(1)
    
    try:
        cursor = connection.cursor(dictionary=True)
        
        # 检查数据库中的所有表
        print("\n数据库中的所有表:")
        cursor.execute("SHOW TABLES")
        tables = cursor.fetchall()
        for table in tables:
            table_name = list(table.values())[0]
            print(f"- {table_name}")
            
            # 显示每个表的结构
            print(f"  结构:")
            cursor.execute(f"DESCRIBE {table_name}")
            columns = cursor.fetchall()
            for column in columns:
                print(f"  - {column['Field']}: {column['Type']} (允许空值: {column['Null']}, 主键: {column['Key']})")
            print()
        
        cursor.close()
    finally:
        if connection and connection.is_connected():
            connection.close()

if __name__ == "__main__":
    check_database_tables()