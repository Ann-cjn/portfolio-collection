import mysql.connector
from app import create_connection

# Test the paid orders filter
connection = create_connection()
if connection and connection.is_connected():
    cursor = connection.cursor(dictionary=True)
    
    print("\nTest: Paid orders filter")
    
    # This is the exact query for paid orders
    query = """SELECT o.order_id, o.user_id, o.total_price, o.status, o.order_time, o.shipping_address, o.billing_address, 
             u.username as user_name, 
             GROUP_CONCAT(CONCAT(pr.name, '(x', oi.quantity, ')') SEPARATOR ', ') as order_products, 
             MAX(p.payment_status) as payment_status
             FROM orders o 
             JOIN users u ON o.user_id = u.user_id 
             LEFT JOIN payments p ON o.order_id = p.order_id
             LEFT JOIN order_items oi ON o.order_id = oi.order_id
             LEFT JOIN products pr ON oi.product_id = pr.product_id
             WHERE 1=1 AND p.payment_status = %s
             GROUP BY o.order_id, o.user_id, o.total_price, o.status, o.order_time, o.shipping_address, o.billing_address, u.username
             ORDER BY o.order_time DESC"""
    
    params = ['completed']
    
    try:
        cursor.execute(query, params)
        results = cursor.fetchall()
        print(f"Paid orders found: {len(results)}")
        for row in results:
            print(f"Order ID: {row['order_id']}, Payment Status: {row['payment_status']}")
        
        # Check what's in the database for these orders
        print("\nDatabase verification:")
        cursor.execute("SELECT * FROM payments WHERE payment_status = 'completed'")
        completed_payments = cursor.fetchall()
        print(f"Completed payments: {len(completed_payments)}")
        
        # Test the count query
        count_query = "SELECT COUNT(*) as count FROM orders o WHERE 1=1 AND EXISTS (SELECT 1 FROM payments WHERE order_id = o.order_id AND payment_status = %s)"
        cursor.execute(count_query, params)
        count_result = cursor.fetchone()
        print(f"Count query result: {count_result['count']}")
        
    except Exception as e:
        print(f"Error: {e}")
    
    cursor.close()
    connection.close()