from app import create_connection

# 连接数据库
conn = create_connection()
if conn and conn.is_connected():
    cursor = conn.cursor()
    
    # 获取所有表
    cursor.execute('SHOW TABLES;')
    tables = cursor.fetchall()
    
    print('数据库表列表:')
    for table in tables:
        print(table[0])
    
    # 获取每个表的结构
    for table in tables:
        table_name = table[0]
        print(f'\n=== {table_name} 表结构 ===')
        cursor.execute(f'DESCRIBE {table_name};')
        columns = cursor.fetchall()
        for column in columns:
            print(f'{column[0]}: {column[1]} (主键: {column[3]}, 可空: {column[2]})')
    
    # 关闭连接
    cursor.close()
    conn.close()
else:
    print('无法连接到数据库')