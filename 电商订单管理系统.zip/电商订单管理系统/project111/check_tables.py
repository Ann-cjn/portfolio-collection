from app import create_connection

# 创建数据库连接
connection = create_connection()
if connection and connection.is_connected():
    cursor = connection.cursor()
    
    # 检查orders表结构
    print('Orders表字段:')
    cursor.execute('SHOW COLUMNS FROM orders')
    for row in cursor.fetchall():
        print(row[0])
    
    # 检查payments表结构
    print('\nPayments表字段:')
    cursor.execute('SHOW COLUMNS FROM payments')
    for row in cursor.fetchall():
        print(row[0])
    
    # 检查特定订单的支付状态
    print('\n订单1的支付状态:')
    cursor.execute('SELECT o.status as order_status, p.payment_status FROM orders o LEFT JOIN payments p ON o.order_id = p.order_id WHERE o.order_id = 1')
    result = cursor.fetchone()
    print(f'订单状态: {result[0]}, 支付状态: {result[1]}')
    
    cursor.close()
    connection.close()