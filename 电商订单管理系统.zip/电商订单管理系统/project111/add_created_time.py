import mysql.connector
from mysql.connector import Error

try:
    # 使用正确的数据库连接参数
    conn = mysql.connector.connect(
        host='127.0.0.1',
        port=3306,
        user='root',
        password='1975819cjn',
        database='ecommerce_db'
    )
    
    if conn.is_connected():
        cursor = conn.cursor()
        
        # 添加created_time字段
        cursor.execute('ALTER TABLE products ADD COLUMN created_time DATETIME DEFAULT CURRENT_TIMESTAMP;')
        conn.commit()
        print("Created_time column added successfully!")
        
        # 显示更新后的表结构
        print("\nUpdated products table structure:")
        print("-" * 60)
        cursor.execute('DESCRIBE products')
        
        for row in cursor.fetchall():
            print(f"{row[0]}: {row[1]} (Null: {row[2]}, Key: {row[3]})")
        
        cursor.close()
        conn.close()
        print("\n-" * 60)
        print("Connection closed.")

except Error as e:
    print(f"Error: {e}")