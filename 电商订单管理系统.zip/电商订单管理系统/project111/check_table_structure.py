from app import create_connection

# 创建数据库连接
connection = create_connection()
if connection and connection.is_connected():
    cursor = connection.cursor()
    
    # 查看order_items表结构
    print("order_items表结构：")
    cursor.execute("DESCRIBE order_items")
    for column in cursor.fetchall():
        print(column)
    
    # 查看products表结构
    print("\nproducts表结构：")
    cursor.execute("DESCRIBE products")
    for column in cursor.fetchall():
        print(column)
    
    # 查看orders表结构
    print("\norders表结构：")
    cursor.execute("DESCRIBE orders")
    for column in cursor.fetchall():
        print(column)
    
    cursor.close()
    connection.close()
    print("\n数据库连接已关闭")
else:
    print("无法连接到数据库")