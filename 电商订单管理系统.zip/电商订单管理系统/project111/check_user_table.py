import mysql.connector
from mysql.connector import Error

# 创建数据库连接
connection = None
try:
    connection = mysql.connector.connect(
        host='127.0.0.1',
        user='root',
        password='1975819cjn',
        database='ecommerce_db'
    )
    
    if connection.is_connected():
        cursor = connection.cursor(dictionary=True)
        
        # 查询用户表结构
        cursor.execute('DESCRIBE users')
        print('用户表结构：')
        for field in cursor.fetchall():
            print(field)
            
        # 查询用户表中的数据
        cursor.execute('SELECT * FROM users LIMIT 5')
        print('\n用户表数据示例：')
        for user in cursor.fetchall():
            print(user)
            
        cursor.close()
        
except Error as e:
    print(f"数据库连接错误: {e}")
finally:
    if connection and connection.is_connected():
        connection.close()