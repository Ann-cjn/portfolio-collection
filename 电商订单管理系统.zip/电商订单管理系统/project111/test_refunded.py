import mysql.connector
from app import create_connection

# Test the refunded status filter that the user is trying to use
connection = create_connection()
if connection and connection.is_connected():
    cursor = connection.cursor(dictionary=True)
    
    print("\nTest: Payment status = 'refunded'")
    
    # This is the exact query that would be generated for refunded status
    query = """SELECT o.order_id, o.user_id, o.total_price, o.status, o.order_time, o.shipping_address, o.billing_address, 
             u.username as user_name, 
             GROUP_CONCAT(CONCAT(pr.name, '(x', oi.quantity, ')') SEPARATOR ', ') as order_products, 
             MAX(p.payment_status) as payment_status
             FROM orders o 
             JOIN users u ON o.user_id = u.user_id 
             LEFT JOIN payments p ON o.order_id = p.order_id
             LEFT JOIN order_items oi ON o.order_id = oi.order_id
             LEFT JOIN products pr ON oi.product_id = pr.product_id
             WHERE 1=1 AND p.payment_status = %s
             GROUP BY o.order_id, o.user_id, o.total_price, o.status, o.order_time, o.shipping_address, o.billing_address, u.username
             ORDER BY o.order_time DESC"""
    
    count_query = "SELECT COUNT(*) as count FROM orders o WHERE 1=1 AND EXISTS (SELECT 1 FROM payments WHERE order_id = o.order_id AND payment_status = %s)"
    
    params = ['refunded']
    
    try:
        cursor.execute(query, params)
        results = cursor.fetchall()
        print(f"Results for refunded filter: {len(results)} orders")
        
        # Check what's actually in the database
        print("\nAll payment records in the database:")
        cursor.execute("SELECT * FROM payments")
        all_payments = cursor.fetchall()
        for payment in all_payments:
            print(f"Order ID: {payment['order_id']}, Status: {payment['payment_status']}")
        
        # The issue is that there are no refunded payments in the database
        print("\nConclusion:")
        print("The filter is working correctly, but there are no 'refunded' payments in the database.")
        print("All payments are currently in 'completed' status.")
        
    except Exception as e:
        print(f"Error: {e}")
    
    cursor.close()
    connection.close()