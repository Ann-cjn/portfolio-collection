import mysql.connector
from mysql.connector import Error

# 创建数据库连接
def create_connection():
    connection = None
    try:
        # 首先尝试使用root用户连接（没有密码）
        connection = mysql.connector.connect(
                host='127.0.0.1',
                port=3306,
                user='root',
                database='ecommerce_db'
            )
        return connection
    except Error as e:
        print(f"First connection attempt failed: {e}")
        try:
            # 然后尝试使用root用户连接（带密码）
            connection = mysql.connector.connect(
                host='127.0.0.1',
                port=3306,
                user='root',
                password='1975819cjn',
                database='ecommerce_db'
            )
            return connection
        except Error as e2:
            print(f"Second connection attempt failed: {e2}")
            try:
                # 最后尝试使用ecommerce_user用户连接
                connection = mysql.connector.connect(
                    host='127.0.0.1',
                    port=3306,
                    user='ecommerce_user',
                    password='ecommerce123',
                    database='ecommerce_db'
                )
                return connection
            except Error as e3:
                print(f"Third connection attempt failed: {e3}")
    return None

# 精确测试已退款筛选
def test_refunded_filter_precise():
    connection = create_connection()
    if connection and connection.is_connected():
        cursor = connection.cursor(dictionary=True)
        
        print("=== 精确测试已退款筛选 ===")
        
        # 模拟app.py中的查询逻辑
        payment_status = 'refunded'
        
        # 构建查询语句
        query = """SELECT o.order_id, o.user_id, o.total_price, o.status, o.order_time, o.shipping_address, o.billing_address, 
                 u.username as user_name, 
                 GROUP_CONCAT(CONCAT(pr.name, '(x', oi.quantity, ')') SEPARATOR ', ') as order_products, 
                 MAX(p.payment_status) as payment_status
                 FROM orders o 
                 JOIN users u ON o.user_id = u.user_id 
                 LEFT JOIN payments p ON o.order_id = p.order_id
                 LEFT JOIN order_items oi ON o.order_id = oi.order_id
                 LEFT JOIN products pr ON oi.product_id = pr.product_id
                 WHERE 1=1"""
        count_query = "SELECT COUNT(*) as count FROM orders o WHERE 1=1"
        params = []
        count_params = []
        
        # 添加支付状态筛选条件
        if payment_status:
            if payment_status == 'paid':
                mapped_status = 'completed'
            elif payment_status == 'unpaid':
                query += " AND (p.payment_status IS NULL OR p.payment_status NOT IN ('completed', 'pending'))"
                count_query += " AND NOT EXISTS (SELECT 1 FROM payments WHERE order_id = o.order_id AND payment_status IN ('completed', 'pending'))"
            elif payment_status == 'refunded':
                mapped_status = 'refunded'
            else:
                mapped_status = payment_status
                
            if payment_status != 'unpaid':
                query += " AND p.payment_status = %s"
                count_query += " AND EXISTS (SELECT 1 FROM payments WHERE order_id = o.order_id AND payment_status = %s)"
                params.append(mapped_status)
                count_params.append(mapped_status)
        
        # 添加分组
        query += " GROUP BY o.order_id, o.user_id, o.total_price, o.status, o.order_time, o.shipping_address, o.billing_address, u.username"
        
        # 执行查询
        print(f"\n1. 执行的主查询:")
        print(f"   {query} WITH params: {params}")
        cursor.execute(query, params)
        orders = cursor.fetchall()
        print(f"   查询结果: {len(orders)} 条订单")
        for order in orders:
            print(f"   订单ID: {order['order_id']}, 支付状态: {order['payment_status']}")
        
        # 执行计数查询
        print(f"\n2. 执行的计数查询:")
        print(f"   {count_query} WITH count_params: {count_params}")
        cursor.execute(count_query, count_params)
        count_result = cursor.fetchone()
        print(f"   计数结果: {count_result['count']} 条订单")
        
        cursor.close()
        connection.close()
    else:
        print("无法连接到数据库")

if __name__ == "__main__":
    test_refunded_filter_precise()
