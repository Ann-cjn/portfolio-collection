import mysql.connector
from mysql.connector import Error

def create_connection():
    connection = None
    try:
        connection = mysql.connector.connect(
            host='127.0.0.1',
            port=3306,
            user='root',
            password='1975819cjn',
            database='ecommerce_db'
        )
        return connection
    except Error as e:
        print(f'Error: {e}')
        return None

conn = create_connection()
if conn and conn.is_connected():
    cursor = conn.cursor(dictionary=True)
    
    # 查看orders表结构
    print('Orders table structure:')
    cursor.execute('DESCRIBE orders')
    for column in cursor.fetchall():
        print(column)
    
    # 查看订单ID和创建时间的关系
    print('\nOrders order_id and order_time (ordered by order_time):')
    cursor.execute('SELECT order_id, order_time FROM orders ORDER BY order_time')
    for order in cursor.fetchall():
        print(f'order_id: {order["order_id"]}, order_time: {order["order_time"]}')
    
    # 查看订单ID和创建时间的关系（按order_id排序）
    print('\nOrders order_id and order_time (ordered by order_id):')
    cursor.execute('SELECT order_id, order_time FROM orders ORDER BY order_id')
    for order in cursor.fetchall():
        print(f'order_id: {order["order_id"]}, order_time: {order["order_time"]}')
    
    cursor.close()
    conn.close()
else:
    print('Failed to connect to database')
