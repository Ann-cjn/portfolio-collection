import mysql.connector
from mysql.connector import Error
import sys

# 添加项目根目录到Python路径
sys.path.append('C:\\Users\\妮妮\\OneDrive\\桌面\\project111')

from app import create_connection

def test_user_id_assignment():
    """测试用户ID分配逻辑"""
    connection = create_connection()
    if connection and connection.is_connected():
        cursor = connection.cursor()
        
        # 首先查看当前用户ID
        cursor.execute("SELECT user_id FROM users ORDER BY user_id ASC")
        existing_ids = [row[0] for row in cursor.fetchall()]
        print(f"当前用户ID: {existing_ids}")
        
        # 模拟add_user函数中的ID分配逻辑
        new_user_id = None
        if not existing_ids:
            new_user_id = 1
        else:
            max_id = existing_ids[-1]
            for i in range(1, max_id + 2):
                if i not in existing_ids:
                    new_user_id = i
                    break
        
        print(f"计算得到的新用户ID: {new_user_id}")
        
        # 插入一个测试用户，使用计算得到的ID
        try:
            test_username = f"test_user_{new_user_id}"
            test_password = "test_password"
            test_phone = "13800138000"
            test_address = "测试地址"
            
            cursor.execute(
                "INSERT INTO users (user_id, username, password, phone, address) VALUES (%s, %s, %s, %s, %s)",
                (new_user_id, test_username, test_password, test_phone, test_address)
            )
            connection.commit()
            print(f"成功插入测试用户，ID: {new_user_id}")
            
            # 验证插入后的用户ID
            cursor.execute("SELECT user_id FROM users ORDER BY user_id ASC")
            updated_ids = [row[0] for row in cursor.fetchall()]
            print(f"插入后用户ID: {updated_ids}")
            
        except Error as e:
            connection.rollback()
            print(f"插入测试用户失败: {str(e)}")
        
        cursor.close()
        connection.close()
    else:
        print("无法连接到数据库")

if __name__ == '__main__':
    test_user_id_assignment()