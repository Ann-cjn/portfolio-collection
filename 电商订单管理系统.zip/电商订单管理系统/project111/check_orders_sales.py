import mysql.connector
from mysql.connector import Error

# 数据库连接函数，与app.py中的相同
def create_connection():
    connection = None
    try:
        # 首先尝试使用root用户连接（没有密码）
        connection = mysql.connector.connect(
                host='127.0.0.1',
                port=3306,
                user='root',
                database='ecommerce_db'
            )
        return connection
    except Error as e:
        print(f"First connection attempt failed: {e}")
        try:
            # 然后尝试使用root用户连接（带密码）
            connection = mysql.connector.connect(
                host='127.0.0.1',
                port=3306,
                user='root',
                password='1975819cjn',
                database='ecommerce_db'
            )
            return connection
        except Error as e2:
            print(f"Second connection attempt failed: {e2}")
            try:
                # 最后尝试使用ecommerce_user用户连接
                connection = mysql.connector.connect(
                    host='127.0.0.1',
                    port=3306,
                    user='ecommerce_user',
                    password='ecommerce123',
                    database='ecommerce_db'
                )
                return connection
            except Error as e3:
                print(f"Third connection attempt failed: {e3}")
    return connection

# 主程序
connection = create_connection()
if connection and connection.is_connected():
    print("Database connection established!")
    cursor = connection.cursor()
    
    # 查看orders表结构
    cursor.execute("DESCRIBE orders")
    print("\nOrders Table Structure:")
    for column in cursor.fetchall():
        print(column)
    
    # 查看所有订单状态及其数量
    cursor.execute("SELECT status, COUNT(*) as count FROM orders GROUP BY status")
    print("\nOrders Status Count:")
    for row in cursor.fetchall():
        print(row)
    
    # 查看所有订单的详细信息，包括支付状态
    print("\nAll Orders with Payment Status:")
    cursor.execute("""
        SELECT o.order_id, o.status, o.order_time, o.total_price, 
               p.payment_status, p.payment_date
        FROM orders o
        LEFT JOIN payments p ON o.order_id = p.order_id
        ORDER BY o.order_id
    """)
    for row in cursor.fetchall():
        print(row)
    
    # 尝试不同的状态查询月度销售
    print("\nMonthly Sales with status='processing':")
    cursor.execute("""
        SELECT DATE_FORMAT(order_time, '%Y-%m') as month, 
               SUM(total_price) as sales_amount, COUNT(*) as order_count 
               FROM orders WHERE status = 'processing' 
               GROUP BY DATE_FORMAT(order_time, '%Y-%m') 
               ORDER BY month
    """)
    sales_data = cursor.fetchall()
    if sales_data:
        for row in sales_data:
            print(row)
    else:
        print("No sales data found!")
    
    # 尝试查看所有状态的月度汇总
    print("\nMonthly Sales with all statuses:")
    cursor.execute("""
        SELECT DATE_FORMAT(order_time, '%Y-%m') as month, 
               SUM(total_price) as sales_amount, COUNT(*) as order_count, status
               FROM orders 
               GROUP BY DATE_FORMAT(order_time, '%Y-%m'), status 
               ORDER BY month, status
    """)
    sales_data = cursor.fetchall()
    if sales_data:
        for row in sales_data:
            print(row)
    else:
        print("No sales data found!")
    
    # 检查payments表的支付状态
    print("\nPayments Table Payment Statuses:")
    cursor.execute("SELECT payment_status, COUNT(*) as count FROM payments GROUP BY payment_status")
    for row in cursor.fetchall():
        print(row)
    
    # 检查哪些订单有支付记录
    print("\nOrders with Payment Records:")
    cursor.execute("""
        SELECT o.order_id, o.status, o.total_price, 
               p.payment_status, p.amount
        FROM orders o
        JOIN payments p ON o.order_id = p.order_id
    """)
    for row in cursor.fetchall():
        print(row)
    
    cursor.close()
    connection.close()
    print("\nDatabase connection closed!")
else:
    print("Failed to connect to database!")