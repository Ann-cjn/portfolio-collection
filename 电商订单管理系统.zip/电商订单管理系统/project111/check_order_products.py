from app import create_connection

# 创建数据库连接
connection = create_connection()
if connection and connection.is_connected():
    cursor = connection.cursor(dictionary=True)
    
    # 检查所有订单及其关联的商品
    print("所有订单及其关联的商品：")
    cursor.execute("""
        SELECT o.order_id, o.total_price, 
               GROUP_CONCAT(CONCAT(pr.name, '(x', oi.quantity, ')') SEPARATOR ', ') as order_products,
               COUNT(oi.item_id) as item_count
        FROM orders o
        LEFT JOIN order_items oi ON o.order_id = oi.order_id
        LEFT JOIN products pr ON oi.product_id = pr.product_id
        GROUP BY o.order_id, o.total_price
        ORDER BY o.order_id
    """)
    orders = cursor.fetchall()
    
    for order in orders:
        print(f"订单ID: {order['order_id']}, 总金额: {order['total_price']}, 商品: {order['order_products'] or '无商品'}, 订单项数量: {order['item_count']}")
    
    # 检查没有商品的订单
    print("\n没有商品的订单：")
    cursor.execute("""
        SELECT o.order_id, o.total_price, o.status, o.order_time
        FROM orders o
        LEFT JOIN order_items oi ON o.order_id = oi.order_id
        GROUP BY o.order_id, o.total_price, o.status, o.order_time
        HAVING COUNT(oi.item_id) = 0
    """)
    empty_orders = cursor.fetchall()
    
    if empty_orders:
        for order in empty_orders:
            print(f"订单ID: {order['order_id']}, 总金额: {order['total_price']}, 状态: {order['status']}, 创建时间: {order['order_time']}")
    else:
        print("没有发现没有商品的订单")
    
    # 检查订单项和商品的关联情况
    print("\n订单项和商品的关联情况：")
    cursor.execute("""
        SELECT oi.item_id, oi.order_id, oi.product_id, oi.quantity, pr.name as product_name
        FROM order_items oi
        LEFT JOIN products pr ON oi.product_id = pr.product_id
        ORDER BY oi.order_id
    """)
    order_items = cursor.fetchall()
    
    for item in order_items:
        print(f"订单项ID: {item['item_id']}, 订单ID: {item['order_id']}, 商品ID: {item['product_id']}, 数量: {item['quantity']}, 商品名称: {item['product_name'] or '无商品'}")
    
    cursor.close()
    connection.close()
    print("\n数据库连接已关闭")
else:
    print("无法连接到数据库")