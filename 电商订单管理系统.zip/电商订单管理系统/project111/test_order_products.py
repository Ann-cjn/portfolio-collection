import mysql.connector
from mysql.connector import Error
import sys

# 数据库连接函数
def create_connection():
    connection = None
    try:
        # 尝试使用root用户连接（有密码）
        connection = mysql.connector.connect(
                host='127.0.0.1',
                port=3306,
                user='root',
                password='1975819cjn',
                database='ecommerce_db'
            )
        return connection
    except Error as e:
        print(f"First connection attempt failed: {e}")
        try:
            # 尝试使用ecommerce_user用户连接
            connection = mysql.connector.connect(
                host='127.0.0.1',
                port=3306,
                user='ecommerce_user',
                password='ecommerce123',
                database='ecommerce_db'
            )
            return connection
        except Error as e2:
            print(f"Second connection attempt failed: {e2}")
    return connection

# 测试函数
def test_order_products_display():
    connection = create_connection()
    if connection and connection.is_connected():
        cursor = connection.cursor(dictionary=True)
        print("\n=== 测试订单商品显示情况 ===")
        
        # 查询所有订单，检查商品显示
        query = """SELECT o.order_id, o.user_id, o.total_price, o.status, 
                 CASE 
                     WHEN COUNT(oi.item_id) = 0 THEN '商品已删除'  -- 没有商品记录
                     ELSE COALESCE(GROUP_CONCAT(CONCAT(pr.name, '(x', oi.quantity, ')') SEPARATOR ', '), '商品已删除')
                 END as order_products
                 FROM orders o 
                 LEFT JOIN order_items oi ON o.order_id = oi.order_id
                 LEFT JOIN products pr ON oi.product_id = pr.product_id
                 GROUP BY o.order_id, o.user_id, o.total_price, o.status
                 ORDER BY o.order_id"""
        
        cursor.execute(query)
        orders = cursor.fetchall()
        
        if not orders:
            print("没有找到任何订单记录")
            return
            
        for order in orders:
            print(f"\n订单ID: {order['order_id']}")
            print(f"用户ID: {order['user_id']}")
            print(f"订单金额: {order['total_price']}")
            print(f"订单状态: {order['status']}")
            print(f"购买商品: {order['order_products']}")
        
        # 检查每个订单的商品详情
        print("\n=== 测试订单商品详情 ===")
        
        for order in orders:
            print(f"\n订单ID: {order['order_id']} 的商品详情:")
            
            # 查询该订单的所有商品项目
            cursor.execute("""
                SELECT oi.item_id, oi.product_id, oi.quantity, pr.name
                FROM order_items oi
                LEFT JOIN products pr ON oi.product_id = pr.product_id
                WHERE oi.order_id = %s
            """, (order['order_id'],))
            
            items = cursor.fetchall()
            if not items:
                print("  - 没有商品项目记录")
            else:
                for item in items:
                    product_name = item['name'] if item['name'] else "商品已删除"
                    print(f"  - 商品ID: {item['product_id']}, 数量: {item['quantity']}, 商品名称: {product_name}")
        
        cursor.close()
        connection.close()
    else:
        print("无法连接到数据库")

if __name__ == "__main__":
    test_order_products_display()
