import mysql.connector
from mysql.connector import Error

try:
    # 使用正确的数据库连接参数
    conn = mysql.connector.connect(
        host='127.0.0.1',
        port=3306,
        user='root',
        password='1975819cjn',
        database='ecommerce_db'
    )
    
    if conn.is_connected():
        cursor = conn.cursor()
        
        # 1. 显示表结构
        print("1. Products table structure:")
        print("-" * 60)
        cursor.execute('DESCRIBE products')
        
        for row in cursor.fetchall():
            print(f"{row[0]}: {row[1]} (Null: {row[2]}, Key: {row[3]})")
        
        # 2. 显示列名
        print("\n2. Products table columns:")
        print("-" * 60)
        cursor.execute('SELECT * FROM products LIMIT 1')
        columns = [desc[0] for desc in cursor.description]
        print(columns)
        
        # 3. 显示示例数据
        print("\n3. Sample product data:")
        print("-" * 60)
        cursor.execute('SELECT * FROM products LIMIT 3')
        rows = cursor.fetchall()
        
        if rows:
            for i, row in enumerate(rows):
                print(f"\nProduct {i+1}:")
                for j, value in enumerate(row):
                    print(f"  {columns[j]}: {value}")
        else:
            print("No products found.")
        
        cursor.close()
        conn.close()
        print("\n-" * 60)
        print("Connection closed.")

except Error as e:
    print(f"Error: {e}")