import mysql.connector
from mysql.connector import Error

def create_connection():
    connection = None
    try:
        connection = mysql.connector.connect(
            host='127.0.0.1',
            port=3306,
            user='root',
            password='1975819cjn',
            database='ecommerce_db'
        )
        return connection
    except Error as e:
        print(f'Error: {e}')
        return None

conn = create_connection()
if conn and conn.is_connected():
    cursor = conn.cursor()
    
    print('开始重置数据库并重新插入测试数据...')
    
    try:
        # 设置外键检查为0
        cursor.execute('SET FOREIGN_KEY_CHECKS = 0')
        
        # 删除现有数据（按依赖关系顺序）
        cursor.execute('TRUNCATE TABLE payments')
        cursor.execute('TRUNCATE TABLE order_items')
        cursor.execute('TRUNCATE TABLE orders')
        cursor.execute('TRUNCATE TABLE users')
        cursor.execute('TRUNCATE TABLE products')
        
        print('现有数据已删除')
        
        # 重新插入测试数据
        import insert_test_data
        
        print('测试数据已重新插入')
        
    except Error as e:
        print(f'错误: {e}')
        conn.rollback()
    finally:
        # 恢复外键检查
        cursor.execute('SET FOREIGN_KEY_CHECKS = 1')
        cursor.close()
        conn.close()
        print('数据库连接已关闭')
else:
    print('无法连接到数据库')
