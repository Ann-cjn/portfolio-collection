import mysql.connector
from mysql.connector import Error

try:
    # 使用正确的数据库连接参数
    conn = mysql.connector.connect(
        host='127.0.0.1',
        port=3306,
        user='root',
        password='1975819cjn',
        database='ecommerce_db'
    )
    
    if conn.is_connected():
        cursor = conn.cursor()
        
        # 显示order_items表结构
        print("Order_items table structure:")
        print("-" * 60)
        cursor.execute('DESCRIBE order_items')
        
        for row in cursor.fetchall():
            print(f"{row[0]}: {row[1]} (Null: {row[2]}, Key: {row[3]})")
        
        # 显示一条order_items示例数据
        print("\nSample order_items data:")
        print("-" * 60)
        cursor.execute('SELECT * FROM order_items LIMIT 1')
        item = cursor.fetchone()
        if item:
            cursor.execute('DESCRIBE order_items')
            columns = [desc[0] for desc in cursor.description]
            for i, value in enumerate(item):
                print(f"  {columns[i]}: {value}")
        
        cursor.close()
        conn.close()
        print("\n-" * 60)
        print("Connection closed.")


except Error as e:
    print(f"Error: {e}")
