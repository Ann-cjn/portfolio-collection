import mysql.connector
from mysql.connector import Error
from datetime import datetime

# 创建数据库连接
def create_connection():
    connection = None
    try:
        # 尝试使用root用户连接（带密码）
        connection = mysql.connector.connect(
            host='127.0.0.1',
            port=3306,
            user='root',
            password='1975819cjn',
            database='ecommerce_db'
        )
        return connection
    except Error as e:
        print(f"数据库连接失败: {e}")
    return connection

# 主程序
try:
    # 创建数据库连接
    connection = create_connection()
    if connection and connection.is_connected():
        cursor = connection.cursor()
        
        print("开始更新用户地址...")
        
        # 更新现有用户的地址
        cursor.execute("UPDATE users SET address = '北京市朝阳区' WHERE username = 'admin'")
        cursor.execute("UPDATE users SET address = '上海市浦东新区' WHERE username = 'user1'")
        cursor.execute("UPDATE users SET address = '广州市天河区' WHERE username = 'user2'")
        
        connection.commit()
        
        # 验证地址更新
        cursor.execute("SELECT user_id, username, address FROM users")
        print("更新后的用户地址:")
        for user in cursor.fetchall():
            print(f"用户ID: {user[0]}, 用户名: {user[1]}, 地址: {user[2]}")
        
        print("\n用户地址更新完成！")
        
    else:
        print("无法连接到数据库")
        
except Error as e:
    print(f"错误：{e}")
    if connection:
        connection.rollback()
finally:
    if connection and connection.is_connected():
        cursor.close()
        connection.close()
        print("\n数据库连接已关闭")