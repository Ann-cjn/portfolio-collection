import mysql.connector
from mysql.connector import Error

# 创建数据库连接
def create_connection():
    connection = None
    try:
        # 首先尝试使用root用户连接（没有密码）
        connection = mysql.connector.connect(
                host='127.0.0.1',
                port=3306,
                user='root',
                database='ecommerce_db'
            )
        return connection
    except Error as e:
        print(f"First connection attempt failed: {e}")
        try:
            # 然后尝试使用root用户连接（带密码）
            connection = mysql.connector.connect(
                host='127.0.0.1',
                port=3306,
                user='root',
                password='1975819cjn',
                database='ecommerce_db'
            )
            return connection
        except Error as e2:
            print(f"Second connection attempt failed: {e2}")
            try:
                # 最后尝试使用ecommerce_user用户连接
                connection = mysql.connector.connect(
                    host='127.0.0.1',
                    port=3306,
                    user='ecommerce_user',
                    password='ecommerce123',
                    database='ecommerce_db'
                )
                return connection
            except Error as e3:
                print(f"Third connection attempt failed: {e3}")
    return connection

# 主程序
try:
    # 创建数据库连接
    connection = create_connection()
    if connection and connection.is_connected():
        cursor = connection.cursor(dictionary=True)
        
        # 查询products表中的所有数据
        cursor.execute("SELECT * FROM products")
        products = cursor.fetchall()
        
        print(f"products表中共有 {len(products)} 条数据：")
        for product in products:
            print(product)
            
        # 查询products表的结构
        print("\nproducts表结构：")
        cursor.execute("DESCRIBE products")
        for column in cursor.fetchall():
            print(column)
            
except Error as e:
    print(f"错误：{e}")
finally:
    if connection and connection.is_connected():
        cursor.close()
        connection.close()
        print("\n数据库连接已关闭")