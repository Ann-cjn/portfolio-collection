import mysql.connector
from mysql.connector import Error

def create_connection():
    connection = None
    try:
        # 首先尝试使用root用户连接（带密码）
        connection = mysql.connector.connect(
            host='127.0.0.1',
            port=3306,
            user='root',
            password='1975819cjn',
            database='ecommerce_db'
        )
        return connection
    except Error as e:
        print(f"连接失败: {e}")
        return None

def check_users_table():
    connection = create_connection()
    if connection and connection.is_connected():
        cursor = connection.cursor()
        
        # 查看表结构
        cursor.execute('DESCRIBE users')
        table_structure = cursor.fetchall()
        
        print('Users表结构:')
        print('-' * 70)
        print('Field\t\tType\t\tNull\tKey\tDefault\tExtra')
        print('-' * 70)
        for field in table_structure:
            field_name = field[0]
            field_type = field[1]
            field_null = field[2]
            field_key = field[3]
            field_default = field[4] if field[4] is not None else ''
            field_extra = field[5]
            print(f'{field_name}\t\t{field_type}\t\t{field_null}\t{field_key}\t{field_default}\t{field_extra}')
        
        # 查看现有用户ID
        cursor.execute('SELECT user_id FROM users ORDER BY user_id ASC')
        user_ids = cursor.fetchall()
        
        print('\n现有用户ID:')
        print('-' * 70)
        for user_id in user_ids:
            print(user_id[0])
        
        cursor.close()
        connection.close()
    else:
        print('无法连接到数据库')

if __name__ == '__main__':
    check_users_table()