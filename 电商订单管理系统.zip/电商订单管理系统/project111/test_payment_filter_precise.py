import requests

# 更精确地测试支付状态筛选功能
def test_payment_filter_precise():
    base_url = 'http://127.0.0.1:5001/orders'
    
    print("=== 精确测试支付状态筛选功能 ===")
    
    # 测试已退款筛选 (refunded) - 检查具体订单ID和支付状态
    print("\n1. 测试已退款筛选 (refunded):")
    response = requests.get(base_url, params={'payment_status': 'refunded'})
    if response.status_code == 200:
        html_content = response.text
        
        # 提取订单信息
        order_ids = []
        payment_statuses = []
        
        # 查找所有订单行
        lines = html_content.split('\n')
        in_order_row = False
        for line in lines:
            if '<tr>' in line and '<thead>' not in line:
                in_order_row = True
                current_order = {'id': None, 'status': None}
            elif '</tr>' in line and in_order_row:
                in_order_row = False
                if current_order['id']:
                    order_ids.append(current_order['id'])
                    payment_statuses.append(current_order['status'])
            elif in_order_row:
                # 提取订单ID
                if '<td>' in line and current_order['id'] is None:
                    td_content = line.split('<td>')[1].split('</td>')[0].strip()
                    if td_content.isdigit():
                        current_order['id'] = td_content
                # 提取支付状态
                if 'badge' in line:
                    if '未支付' in line:
                        current_order['status'] = '未支付'
                    elif '已支付' in line:
                        current_order['status'] = '已支付'
                    elif '已退款' in line:
                        current_order['status'] = '已退款'
        
        print(f"   实际订单ID: {order_ids}")
        print(f"   实际支付状态: {payment_statuses}")
        print(f"   实际订单数量: {len(order_ids)}")
        
        # 验证结果
        if len(order_ids) == 0:
            print("   ✓ 正确：没有退款订单")
        else:
            print("   ! 注意：返回了订单，但数据库中没有退款记录")
            print("   ! 可能是LEFT JOIN导致的空支付状态记录")
    else:
        print(f"   请求失败: {response.status_code}")
    
    print("\n=== 测试完成 ===")

if __name__ == "__main__":
    test_payment_filter_precise()
