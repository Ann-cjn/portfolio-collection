import mysql.connector
from mysql.connector import Error

# 连接到MySQL数据库
try:
    # 首先尝试使用root用户连接（没有密码）
    cnx = mysql.connector.connect(
        host='127.0.0.1',
        port=3306,
        user='root',
        database='ecommerce_db'
    )
except Error as e:
    print(f"First connection attempt failed: {e}")
    try:
        # 然后尝试使用root用户连接（带密码）
        cnx = mysql.connector.connect(
            host='127.0.0.1',
            port=3306,
            user='root',
            password='1975819cjn',
            database='ecommerce_db'
        )
    except Error as e2:
        print(f"Second connection attempt failed: {e2}")
        try:
            # 最后尝试使用ecommerce_user用户连接
            cnx = mysql.connector.connect(
                host='127.0.0.1',
                port=3306,
                user='ecommerce_user',
                password='ecommerce123',
                database='ecommerce_db'
            )
        except Error as e3:
            print(f"Third connection attempt failed: {e3}")
            raise

cursor = cnx.cursor()

try:
    # 向users表添加address字段
    cursor.execute("ALTER TABLE users ADD COLUMN address VARCHAR(255) DEFAULT NULL")
    print("成功向users表添加address字段")
    
    # 提交事务
    cnx.commit()
except Error as e:
    if "Duplicate column name" in str(e):
        print("address字段已存在")
    else:
        print(f"添加address字段失败: {e}")
finally:
    # 关闭游标和连接
    cursor.close()
    cnx.close()