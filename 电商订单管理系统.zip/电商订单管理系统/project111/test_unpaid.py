import mysql.connector
from app import create_connection

# Test the unpaid orders filter
connection = create_connection()
if connection and connection.is_connected():
    cursor = connection.cursor(dictionary=True)
    
    print("\nTest: Unpaid orders filter")
    
    # This is the exact query for unpaid orders
    query = """SELECT o.order_id, o.user_id, o.total_price, o.status, o.order_time, o.shipping_address, o.billing_address, 
             u.username as user_name, 
             GROUP_CONCAT(CONCAT(pr.name, '(x', oi.quantity, ')') SEPARATOR ', ') as order_products, 
             MAX(p.payment_status) as payment_status
             FROM orders o 
             JOIN users u ON o.user_id = u.user_id 
             LEFT JOIN payments p ON o.order_id = p.order_id
             LEFT JOIN order_items oi ON o.order_id = oi.order_id
             LEFT JOIN products pr ON oi.product_id = pr.product_id
             WHERE 1=1 AND (p.payment_status IS NULL OR p.payment_status NOT IN ('completed', 'pending'))
             GROUP BY o.order_id, o.user_id, o.total_price, o.status, o.order_time, o.shipping_address, o.billing_address, u.username
             ORDER BY o.order_time DESC"""
    
    try:
        cursor.execute(query)
        results = cursor.fetchall()
        print(f"Unpaid orders found: {len(results)}")
        for row in results:
            print(f"Order ID: {row['order_id']}, Payment Status: {row['payment_status']}")
        
        # Check all orders to see which have payments
        print("\nAll orders in the system:")
        cursor.execute("SELECT o.order_id, o.status, p.payment_status FROM orders o LEFT JOIN payments p ON o.order_id = p.order_id")
        all_orders = cursor.fetchall()
        for order in all_orders:
            print(f"Order ID: {order['order_id']}, Status: {order['status']}, Payment Status: {order['payment_status']}")
        
    except Exception as e:
        print(f"Error: {e}")
    
    cursor.close()
    connection.close()