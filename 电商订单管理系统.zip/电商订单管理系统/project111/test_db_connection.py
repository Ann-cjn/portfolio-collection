import mysql.connector
from mysql.connector import Error

# 测试数据库连接
try:
    # 尝试连接到MySQL服务器（不指定数据库）
    connection = mysql.connector.connect(
        host='localhost',
        port=3306,
        user='root',
        password='1975819cjn'  # 使用正确的密码
    )
    
    if connection.is_connected():
        db_Info = connection.get_server_info()
        print(f"成功连接到MySQL服务器，版本：{db_Info}")
        
        # 创建数据库（如果不存在）
        cursor = connection.cursor()
        cursor.execute("CREATE DATABASE IF NOT EXISTS ecommerce_db")
        print("数据库 'ecommerce_db' 创建成功或已存在")
        
        # 关闭连接
        cursor.close()
        connection.close()
        print("MySQL连接已关闭")
        
except Error as e:
    print(f"连接失败: {e}")
    print("请检查以下几点：")
    print("1. MySQL服务器是否正在运行")
    print("2. 用户名和密码是否正确")
    print("3. 是否有足够的权限创建数据库")

# 测试连接到指定数据库
try:
    connection = mysql.connector.connect(
        host='localhost',
        port=3306,
        user='root',
        password='1975819cjn',
        database='ecommerce_db'
    )
    
    if connection.is_connected():
        print(f"成功连接到数据库 'ecommerce_db'")
        connection.close()
        print("MySQL连接已关闭")
        
except Error as e:
    print(f"连接到指定数据库失败: {e}")
    print("数据库可能不存在或用户没有访问权限")