import mysql.connector
from mysql.connector import Error
from datetime import datetime, timedelta

# 创建数据库连接
def create_connection():
    connection = None
    try:
        # 尝试使用root用户连接（带密码）
        connection = mysql.connector.connect(
            host='127.0.0.1',
            port=3306,
            user='root',
            password='1975819cjn',
            database='ecommerce_db'
        )
        return connection
    except Error as e:
        print(f"数据库连接失败: {e}")
    return connection

# 主程序
try:
    # 创建数据库连接
    connection = create_connection()
    if connection and connection.is_connected():
        cursor = connection.cursor()
        
        print("开始重置测试数据...")
        
        # 1. 删除现有数据（注意顺序，先删除外键引用的表）
        cursor.execute("DELETE FROM payments")
        cursor.execute("DELETE FROM order_items")
        cursor.execute("DELETE FROM orders")
        cursor.execute("DELETE FROM products")
        cursor.execute("DELETE FROM users")
        print("现有数据已清除")
        
        # 2. 插入用户数据
        users = [
            ('admin', '123456', '13800138000', '北京市朝阳区', datetime.now(), 'admin'),
            ('user1', '123456', '13800138001', '上海市浦东新区', datetime.now(), 'customer'),
            ('user2', '123456', '13800138002', '广州市天河区', datetime.now(), 'customer')
        ]
        cursor.executemany("INSERT INTO users (username, password, phone, address, create_time, role) VALUES (%s, %s, %s, %s, %s, %s)", users)
        print(f"插入了 {cursor.rowcount} 个用户")
        
        # 3. 插入商品数据
        products = [
            ('iPhone 15 Pro', 8999.00, 100, '手机'),
            ('MacBook Pro 14', 19999.00, 50, '笔记本电脑'),
            ('AirPods Pro', 1899.00, 200, '耳机'),
            ('iPad Air', 4799.00, 80, '平板'),
            ('Apple Watch Series 9', 2999.00, 150, '智能手表'),
            ('小米14', 4999.00, 120, '手机'),
            ('华为Mate 60', 6999.00, 90, '手机'),
            ('联想ThinkPad X1', 12999.00, 40, '笔记本电脑'),
            ('索尼WH-1000XM5', 2999.00, 60, '耳机'),
            ('三星Galaxy S23', 6499.00, 70, '手机')
        ]
        cursor.executemany("INSERT INTO products (name, price, stock, category) VALUES (%s, %s, %s, %s)", products)
        print(f"插入了 {cursor.rowcount} 个商品")
        
        # 4. 插入订单数据
        orders = [
            (2, 2999.00, datetime.now() - timedelta(days=3), '已送达'),  # order_id=1
            (2, 19999.00, datetime.now() - timedelta(days=2), '已发货'),  # order_id=2
            (2, 8999.00, datetime.now() - timedelta(days=1), '处理中'),  # order_id=3
            (3, 1899.00, datetime.now() - timedelta(hours=12), '待处理'),  # order_id=4
            (3, 4799.00, datetime.now() - timedelta(hours=6), '待处理')  # order_id=5
        ]
        cursor.executemany("INSERT INTO orders (user_id, total_price, order_time, status) VALUES (%s, %s, %s, %s)", orders)
        print(f"插入了 {cursor.rowcount} 个订单")
        
        # 5. 插入订单商品数据
        order_items = [
            (1, 5, 1, 2999.00),  # order_id=1, product=Apple Watch Series 9
            (2, 2, 1, 19999.00),  # order_id=2, product=MacBook Pro 14
            (3, 1, 1, 8999.00),  # order_id=3, product=iPhone 15 Pro
            (4, 3, 1, 1899.00),  # order_id=4, product=AirPods Pro
            (5, 4, 1, 4799.00)  # order_id=5, product=iPad Air
        ]
        cursor.executemany("INSERT INTO order_items (order_id, product_id, quantity, price) VALUES (%s, %s, %s, %s)", order_items)
        print(f"插入了 {cursor.rowcount} 个订单商品")
        
        # 6. 插入支付数据
        payments = [
            (1, '微信支付', 'completed', 2999.00, datetime.now() - timedelta(days=3)),  # order_id=1
            (2, '支付宝', 'completed', 19999.00, datetime.now() - timedelta(days=2)),  # order_id=2
            (3, '支付宝', 'completed', 8999.00, datetime.now() - timedelta(days=1)),  # order_id=3
            (4, '微信支付', 'completed', 1899.00, datetime.now() - timedelta(hours=12))  # order_id=4
        ]
        cursor.executemany("INSERT INTO payments (order_id, payment_method, payment_status, amount, payment_date) VALUES (%s, %s, %s, %s, %s)", payments)
        print(f"插入了 {cursor.rowcount} 个支付记录")
        
        # 提交事务
        connection.commit()
        print("\n测试数据重置完成！")
        
        # 验证数据插入情况
        cursor.execute("SELECT COUNT(*) FROM users")
        print(f"用户表数据数: {cursor.fetchone()[0]}")
        
        cursor.execute("SELECT * FROM users")
        print("用户数据:")
        for user in cursor.fetchall():
            print(user)
        
    else:
        print("无法连接到数据库")
        
except Error as e:
    print(f"错误：{e}")
    if connection:
        connection.rollback()
finally:
    if connection and connection.is_connected():
        cursor.close()
        connection.close()
        print("\n数据库连接已关闭")