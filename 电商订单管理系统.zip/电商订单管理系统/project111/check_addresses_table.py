import mysql.connector
from mysql.connector import Error

try:
    # 使用正确的数据库连接参数
    conn = mysql.connector.connect(
        host='127.0.0.1',
        port=3306,
        user='root',
        password='1975819cjn',
        database='ecommerce_db'
    )
    
    if conn.is_connected():
        cursor = conn.cursor()
        
        # 检查是否有addresses表
        cursor.execute("SHOW TABLES LIKE 'addresses'")
        table_exists = cursor.fetchone()
        
        if table_exists:
            # 显示addresses表结构
            print("Addresses table structure:")
            print("-" * 60)
            cursor.execute('DESCRIBE addresses')
            
            for row in cursor.fetchall():
                print(f"{row[0]}: {row[1]} (Null: {row[2]}, Key: {row[3]})")
            
            # 显示一条地址示例数据
            print("\nSample address data:")
            print("-" * 60)
            cursor.execute('SELECT * FROM addresses LIMIT 1')
            address = cursor.fetchone()
            if address:
                cursor.execute('DESCRIBE addresses')
                columns = [desc[0] for desc in cursor.description]
                for i, value in enumerate(address):
                    print(f"  {columns[i]}: {value}")
        else:
            print("No addresses table found.")
            
        # 检查所有表
        print("\nAll tables in database:")
        print("-" * 60)
        cursor.execute("SHOW TABLES")
        tables = cursor.fetchall()
        for table in tables:
            print(table[0])
        
        cursor.close()
        conn.close()
        print("\n-" * 60)
        print("Connection closed.")


except Error as e:
    print(f"Error: {e}")
