import mysql.connector
from mysql.connector import Error

# 创建数据库连接
def create_connection():
    connection = None
    try:
        # 首先尝试使用root用户连接（没有密码）
        connection = mysql.connector.connect(
                host='127.0.0.1',
                port=3306,
                user='root',
                database='ecommerce_db'
            )
        return connection
    except Error as e:
        print(f"First connection attempt failed: {e}")
        try:
            # 然后尝试使用root用户连接（带密码）
            connection = mysql.connector.connect(
                host='127.0.0.1',
                port=3306,
                user='root',
                password='1975819cjn',
                database='ecommerce_db'
            )
            return connection
        except Error as e2:
            print(f"Second connection attempt failed: {e2}")
            try:
                # 最后尝试使用ecommerce_user用户连接
                connection = mysql.connector.connect(
                    host='127.0.0.1',
                    port=3306,
                    user='ecommerce_user',
                    password='ecommerce123',
                    database='ecommerce_db'
                )
                return connection
            except Error as e3:
                print(f"Third connection attempt failed: {e3}")
    return connection

# 主程序
try:
    # 创建数据库连接
    connection = create_connection()
    if connection and connection.is_connected():
        cursor = connection.cursor(dictionary=True)
        
        # 获取所有表
        cursor.execute("SHOW TABLES")
        tables = cursor.fetchall()
        
        print("数据库中的所有表及其数据:")
        for table in tables:
            table_name = table['Tables_in_ecommerce_db']
            print(f"\n=== {table_name} 表 ===")
            
            # 查询表中的数据
            cursor.execute(f"SELECT * FROM {table_name}")
            data = cursor.fetchall()
            
            print(f"{table_name}表中共有 {len(data)} 条数据")
            
            # 显示数据
            if len(data) > 0:
                # 显示前5条数据
                print("前5条数据:")
                for i, row in enumerate(data[:5]):
                    print(f"数据 {i+1}: {row}")
                
                # 如果有超过5条数据，显示总数
                if len(data) > 5:
                    print(f"... 还有 {len(data) - 5} 条数据未显示")
            else:
                print("暂无数据")
            
except Error as e:
    print(f"错误：{e}")
finally:
    if connection and connection.is_connected():
        cursor.close()
        connection.close()
        print("\n数据库连接已关闭")