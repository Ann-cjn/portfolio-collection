import mysql.connector
from mysql.connector import Error

try:
    # 使用正确的数据库连接参数
    conn = mysql.connector.connect(
        host='127.0.0.1',
        port=3306,
        user='root',
        password='1975819cjn',
        database='ecommerce_db'
    )
    
    if conn.is_connected():
        cursor = conn.cursor()
        
        # 向orders表添加shipping_address字段
        cursor.execute("ALTER TABLE orders ADD COLUMN shipping_address VARCHAR(255) DEFAULT NULL")
        print("Added shipping_address column to orders table")
        
        # 向orders表添加billing_address字段
        cursor.execute("ALTER TABLE orders ADD COLUMN billing_address VARCHAR(255) DEFAULT NULL")
        print("Added billing_address column to orders table")
        
        conn.commit()
        print("\nChanges committed to database")
        
        cursor.close()
        conn.close()
        print("Connection closed.")


except Error as e:
    print(f"Error: {e}")
