import mysql.connector

def add_role_to_users():
    try:
        connection = mysql.connector.connect(
            host='localhost',
            user='root',
            password='1975819cjn',
            database='ecommerce_db',
            port=3306
        )

        cursor = connection.cursor()
        
        # 检查role字段是否存在
        cursor.execute("SHOW COLUMNS FROM users LIKE 'role'")
        column_exists = cursor.fetchone()
        
        if not column_exists:
            # 在users表中添加role字段，默认为customer
            cursor.execute("ALTER TABLE users ADD COLUMN role ENUM('admin', 'customer') DEFAULT 'customer'")
            print("成功在users表中添加role字段")
        else:
            print("users表中已经存在role字段")
        
        # 提交更改
        connection.commit()
        
    except mysql.connector.Error as error:
        print(f"添加字段时出错: {error}")
    finally:
        if (connection.is_connected()):
            cursor.close()
            connection.close()
            print("MySQL连接已关闭")

if __name__ == "__main__":
    add_role_to_users()