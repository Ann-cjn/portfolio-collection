import mysql.connector
from mysql.connector import Error

# 创建数据库连接
def create_connection():
    connection = None
    try:
        # 首先尝试使用root用户连接（没有密码）
        connection = mysql.connector.connect(
                host='127.0.0.1',
                port=3306,
                user='root',
                database='ecommerce_db'
            )
        return connection
    except Error as e:
        print(f"First connection attempt failed: {e}")
        try:
            # 然后尝试使用root用户连接（带密码）
            connection = mysql.connector.connect(
                host='127.0.0.1',
                port=3306,
                user='root',
                password='1975819cjn',
                database='ecommerce_db'
            )
            return connection
        except Error as e2:
            print(f"Second connection attempt failed: {e2}")
            try:
                # 最后尝试使用ecommerce_user用户连接
                connection = mysql.connector.connect(
                    host='127.0.0.1',
                    port=3306,
                    user='ecommerce_user',
                    password='ecommerce123',
                    database='ecommerce_db'
                )
                return connection
            except Error as e3:
                print(f"Third connection attempt failed: {e3}")
    return connection

# 主程序
try:
    # 创建数据库连接
    connection = create_connection()
    if connection and connection.is_connected():
        cursor = connection.cursor()
        
        # 创建payments表的SQL语句
        create_payments_table = '''
        CREATE TABLE IF NOT EXISTS payments (
            payment_id INT AUTO_INCREMENT PRIMARY KEY,
            order_id INT NOT NULL,
            payment_method VARCHAR(50) NOT NULL,
            payment_status VARCHAR(20) NOT NULL,
            amount DECIMAL(10, 2) NOT NULL,
            payment_date DATETIME NOT NULL,
            FOREIGN KEY (order_id) REFERENCES orders(order_id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
        '''
        
        # 执行创建表的SQL语句
        cursor.execute(create_payments_table)
        connection.commit()
        
        print("payments表创建成功！")
        
        # 查看表结构
        cursor.execute("DESCRIBE payments")
        print("\npayments表结构：")
        for column in cursor.fetchall():
            print(column)
            
except Error as e:
    print(f"错误：{e}")
finally:
    if connection and connection.is_connected():
        cursor.close()
        connection.close()
        print("\n数据库连接已关闭")
