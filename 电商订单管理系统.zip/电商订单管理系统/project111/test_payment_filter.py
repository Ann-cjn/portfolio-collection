import requests
import json

# 测试支付状态筛选功能
def test_payment_status_filtering():
    base_url = 'http://127.0.0.1:5001/orders'
    
    print("=== 测试支付状态筛选功能 ===")
    
    # 测试默认情况（无筛选）
    print("\n1. 测试默认情况（无筛选）:")
    response = requests.get(base_url)
    if response.status_code == 200:
        print(f"   状态码: {response.status_code}")
        print(f"   响应长度: {len(response.text)} 字符")
        # 计算订单数量（通过统计订单行）
        order_count = response.text.count('<tr>') - 1  # 减去表头行
        print(f"   订单数量: {order_count}")
    else:
        print(f"   请求失败: {response.status_code}")
    
    # 测试已支付筛选 (paid)
    print("\n2. 测试已支付筛选 (paid):")
    response = requests.get(base_url, params={'payment_status': 'paid'})
    if response.status_code == 200:
        print(f"   状态码: {response.status_code}")
        print(f"   响应长度: {len(response.text)} 字符")
        order_count = response.text.count('<tr>') - 1
        print(f"   订单数量: {order_count}")
        # 检查是否包含预期的支付状态
        if '已支付' in response.text:
            print("   ✓ 包含'已支付'状态")
    else:
        print(f"   请求失败: {response.status_code}")
    
    # 测试未支付筛选 (unpaid)
    print("\n3. 测试未支付筛选 (unpaid):")
    response = requests.get(base_url, params={'payment_status': 'unpaid'})
    if response.status_code == 200:
        print(f"   状态码: {response.status_code}")
        print(f"   响应长度: {len(response.text)} 字符")
        order_count = response.text.count('<tr>') - 1
        print(f"   订单数量: {order_count}")
        # 检查是否包含预期的支付状态
        if '未支付' in response.text:
            print("   ✓ 包含'未支付'状态")
    else:
        print(f"   请求失败: {response.status_code}")
    
    # 测试已退款筛选 (refunded)
    print("\n4. 测试已退款筛选 (refunded):")
    response = requests.get(base_url, params={'payment_status': 'refunded'})
    if response.status_code == 200:
        print(f"   状态码: {response.status_code}")
        print(f"   响应长度: {len(response.text)} 字符")
        order_count = response.text.count('<tr>') - 1
        print(f"   订单数量: {order_count}")
        # 检查是否包含预期的支付状态
        if '已退款' in response.text or order_count == 0:
            print("   ✓ 符合预期（无退款订单或包含'已退款'状态）")
    else:
        print(f"   请求失败: {response.status_code}")
    
    print("\n=== 测试完成 ===")

if __name__ == "__main__":
    test_payment_status_filtering()
