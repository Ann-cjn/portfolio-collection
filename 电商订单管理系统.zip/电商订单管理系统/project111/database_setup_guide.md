# 电商订单管理系统数据库设置指南

## 步骤1：确保MySQL服务器已安装并运行

1. 确保你已经安装了MySQL服务器
2. 启动MySQL服务
   - Windows: 可以在服务管理器中启动或运行 `net start mysql`
   - Linux: 运行 `sudo systemctl start mysql`
   - macOS: 运行 `brew services start mysql` (如果你使用Homebrew安装)

## 步骤2：创建数据库和用户

1. 打开MySQL命令行工具或使用MySQL Workbench连接到MySQL服务器
2. 登录到MySQL：
   ```sql
   mysql -u root -p
   ```
   然后输入你的MySQL root密码

3. 创建数据库：
   ```sql
   CREATE DATABASE ecommerce_db;
   ```

4. 创建用户（可选，推荐使用非root用户）：
   ```sql
   CREATE USER 'ecommerce_user'@'localhost' IDENTIFIED BY 'your_password';
   ```

5. 为用户授予权限：
   ```sql
   GRANT ALL PRIVILEGES ON ecommerce_db.* TO 'ecommerce_user'@'localhost';
   FLUSH PRIVILEGES;
   ```

## 步骤3：创建表结构

使用以下SQL命令创建电商系统所需的7个表：

1. 商品分类表（categories）
   ```sql
   CREATE TABLE categories (
       category_id INT PRIMARY KEY AUTO_INCREMENT,
       category_name VARCHAR(100) NOT NULL,
       description TEXT,
       created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
   );
   ```

2. 用户表（users）
   ```sql
   CREATE TABLE users (
       user_id INT PRIMARY KEY AUTO_INCREMENT,
       username VARCHAR(50) UNIQUE NOT NULL,
       password VARCHAR(255) NOT NULL,
       email VARCHAR(100) UNIQUE NOT NULL,
       full_name VARCHAR(100) NOT NULL,
       phone VARCHAR(20),
       address TEXT,
       role ENUM('admin', 'customer') DEFAULT 'customer',
       created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
       updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
   );
   ```

3. 商品表（products）
   ```sql
   CREATE TABLE products (
       product_id INT PRIMARY KEY AUTO_INCREMENT,
       product_name VARCHAR(200) NOT NULL,
       description TEXT,
       price DECIMAL(10, 2) NOT NULL CHECK (price > 0),
       stock_quantity INT NOT NULL CHECK (stock_quantity >= 0),
       category_id INT,
       image_url VARCHAR(255),
       created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
       updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
       FOREIGN KEY (category_id) REFERENCES categories(category_id) ON DELETE SET NULL
   );
   ```

4. 订单表（orders）
   ```sql
   CREATE TABLE orders (
       order_id INT PRIMARY KEY AUTO_INCREMENT,
       user_id INT NOT NULL,
       total_amount DECIMAL(10, 2) NOT NULL CHECK (total_amount > 0),
       order_status ENUM('pending', 'processing', 'shipped', 'delivered', 'cancelled') DEFAULT 'pending',
       shipping_address TEXT NOT NULL,
       billing_address TEXT NOT NULL,
       payment_status ENUM('unpaid', 'paid', 'refunded') DEFAULT 'unpaid',
       created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
       updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
       FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
   );
   ```

5. 订单商品表（order_items）
   ```sql
   CREATE TABLE order_items (
       order_item_id INT PRIMARY KEY AUTO_INCREMENT,
       order_id INT NOT NULL,
       product_id INT NOT NULL,
       quantity INT NOT NULL CHECK (quantity > 0),
       unit_price DECIMAL(10, 2) NOT NULL CHECK (unit_price > 0),
       total_price DECIMAL(10, 2) NOT NULL CHECK (total_price > 0),
       FOREIGN KEY (order_id) REFERENCES orders(order_id) ON DELETE CASCADE,
       FOREIGN KEY (product_id) REFERENCES products(product_id) ON DELETE RESTRICT
   );
   ```

6. 支付表（payments）
   ```sql
   CREATE TABLE payments (
       payment_id INT PRIMARY KEY AUTO_INCREMENT,
       order_id INT NOT NULL,
       payment_method VARCHAR(50) NOT NULL,
       amount DECIMAL(10, 2) NOT NULL CHECK (amount > 0),
       payment_status ENUM('pending', 'completed', 'failed', 'refunded') DEFAULT 'pending',
       transaction_id VARCHAR(100),
       payment_date TIMESTAMP,
       FOREIGN KEY (order_id) REFERENCES orders(order_id) ON DELETE CASCADE
   );
   ```

## 步骤4：插入示例数据

插入一些示例数据以便测试：

1. 插入商品分类
   ```sql
   INSERT INTO categories (category_name, description) VALUES
   ('手机数码', '各种智能手机、平板电脑、数码配件等'),
   ('电脑办公', '笔记本电脑、台式机、办公设备等'),
   ('家用电器', '冰箱、洗衣机、电视等家用电器'),
   ('服装鞋帽', '男装、女装、鞋靴、配饰等'),
   ('美妆护肤', '化妆品、护肤品、个人护理用品等');
   ```

2. 插入用户
   ```sql
   INSERT INTO users (username, password, email, full_name, phone, address, role) VALUES
   ('admin', 'admin123', 'admin@example.com', '系统管理员', '13800138000', '北京市朝阳区', 'admin'),
   ('customer1', 'pass123', 'customer1@example.com', '张三', '13900139001', '上海市浦东新区', 'customer'),
   ('customer2', 'pass456', 'customer2@example.com', '李四', '13700137002', '广州市天河区', 'customer'),
   ('customer3', 'pass789', 'customer3@example.com', '王五', '13600136003', '深圳市南山区', 'customer');
   ```

3. 插入商品
   ```sql
   INSERT INTO products (product_name, description, price, stock_quantity, category_id, image_url) VALUES
   ('iPhone 15 Pro', 'Apple iPhone 15 Pro 智能手机', 8999.00, 50, 1, 'https://example.com/iphone15.jpg'),
   ('MacBook Pro', 'Apple MacBook Pro 笔记本电脑', 15999.00, 30, 2, 'https://example.com/macbook.jpg'),
   ('小米14', '小米14 智能手机', 3999.00, 100, 1, 'https://example.com/xiaomi14.jpg'),
   ('华为Mate 60', '华为Mate 60 智能手机', 5999.00, 80, 1, 'https://example.com/huawei.jpg'),
   ('格力空调', '格力 1.5匹 变频空调', 2999.00, 40, 3, 'https://example.com/airconditioner.jpg'),
   ('海尔冰箱', '海尔 500升 双开门冰箱', 4599.00, 25, 3, 'https://example.com/fridge.jpg'),
   ('耐克运动鞋', '耐克 Air Max 运动鞋', 899.00, 120, 4, 'https://example.com/nike.jpg'),
   ('雅诗兰黛面霜', '雅诗兰黛 小棕瓶面霜', 1299.00, 60, 5, 'https://example.com/estee.jpg');
   ```

4. 插入订单
   ```sql
   INSERT INTO orders (user_id, total_amount, order_status, shipping_address, billing_address, payment_status) VALUES
   (2, 8999.00, 'delivered', '上海市浦东新区张杨路123号', '上海市浦东新区张杨路123号', 'paid'),
   (3, 4599.00, 'shipped', '广州市天河区天河路456号', '广州市天河区天河路456号', 'paid'),
   (2, 15999.00, 'processing', '上海市浦东新区张杨路123号', '上海市浦东新区张杨路123号', 'paid'),
   (4, 3999.00, 'pending', '深圳市南山区科技园路789号', '深圳市南山区科技园路789号', 'unpaid');
   ```

5. 插入订单商品
   ```sql
   INSERT INTO order_items (order_id, product_id, quantity, unit_price, total_price) VALUES
   (1, 1, 1, 8999.00, 8999.00),  -- iPhone 15 Pro
   (2, 6, 1, 4599.00, 4599.00),  -- 海尔冰箱
   (3, 2, 1, 15999.00, 15999.00), -- MacBook Pro
   (4, 3, 1, 3999.00, 3999.00);   -- 小米14
   ```

6. 插入支付记录
   ```sql
   INSERT INTO payments (order_id, payment_method, amount, payment_status, transaction_id, payment_date) VALUES
   (1, '支付宝', 8999.00, 'completed', 'alipay123456', NOW()),
   (2, '微信支付', 4599.00, 'completed', 'wechat789012', NOW()),
   (3, '信用卡', 15999.00, 'completed', 'credit345678', NOW()),
   (4, '支付宝', 3999.00, 'pending', NULL, NULL);
   ```

## 步骤5：配置Flask应用连接数据库

修改`app.py`和`init_db.py`中的数据库连接参数：

1. 打开`app.py`文件
2. 找到`create_connection`函数，修改数据库连接参数：
   ```python
   def create_connection():
       connection = None
       try:
           connection = mysql.connector.connect(
               host='localhost',
               user='your_username',  # 可以是root或你创建的用户
               password='your_password',  # 你的MySQL密码
               database='ecommerce_db'
           )
           return connection
       except Error as e:
           print(f"Error connecting to MySQL: {e}")
       return connection
   ```

3. 对`init_db.py`文件做同样的修改

## 步骤6：测试连接

1. 运行数据库初始化脚本（如果需要）：
   ```bash
   python init_db.py
   ```

2. 启动Flask应用：
   ```bash
   python app.py
   ```

3. 在浏览器中访问 `http://localhost:5000`，如果看到首页，则说明数据库连接成功

## 常见问题及解决方法

1. **连接错误 1045 (28000)**: 用户名或密码不正确，请检查连接参数
2. **连接错误 1049 (42000)**: 数据库不存在，请确保已创建数据库
3. **表不存在错误**: 请确保已执行表创建脚本
4. **权限错误**: 确保用户拥有对数据库的正确权限

如果遇到其他问题，请检查MySQL服务是否正在运行，以及连接参数是否正确。