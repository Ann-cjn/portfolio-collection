import mysql.connector
from app import create_connection

connection = create_connection()
if connection and connection.is_connected():
    cursor = connection.cursor(dictionary=True)
    
    # Get all payment records
    cursor.execute('SELECT * FROM payments LIMIT 10')
    payments = cursor.fetchall()
    print('Payment records:')
    for payment in payments:
        print(f"Order ID: {payment['order_id']}, Status: {payment['payment_status']}")
    
    # Get distinct payment statuses
    cursor.execute('SELECT DISTINCT payment_status FROM payments')
    statuses = cursor.fetchall()
    print('\nDistinct payment statuses:')
    for status in statuses:
        print(f"- {status['payment_status']}")
    
    # Check if there are any refunded payments
    cursor.execute('SELECT * FROM payments WHERE payment_status = %s', ('refunded',))
    refunded = cursor.fetchall()
    print(f'\nRefunded payments: {len(refunded)}')
    
    cursor.close()
    connection.close()
