@echo off
REM 创建MySQL用户和数据库的批处理脚本
REM 请确保以管理员身份运行此脚本

REM MySQL服务器参数
set MYSQL_PATH="C:\Program Files\MySQL\MySQL Server 8.0\bin\mysql.exe"
set ROOT_USER=root
set ROOT_PASSWORD=123456
set NEW_USER=ecommerce_user
set NEW_PASSWORD=ecommerce123
set DATABASE_NAME=ecommerce_db

echo ========================================
echo 电商订单管理系统数据库设置脚本
echo ========================================
echo.

REM 测试root连接
echo 正在测试MySQL root连接...
%MYSQL_PATH% -u %ROOT_USER% -p%ROOT_PASSWORD% -e "SELECT VERSION();" >nul 2>&1
if %ERRORLEVEL% equ 0 (
    echo ✓ root连接成功
) else (
    echo ✗ root连接失败，请检查密码是否正确
    echo 请在脚本中修改ROOT_PASSWORD变量，然后重新运行
    pause
    exit /b 1
)

REM 创建数据库
echo 正在创建数据库 '%DATABASE_NAME'...
%MYSQL_PATH% -u %ROOT_USER% -p%ROOT_PASSWORD% -e "CREATE DATABASE IF NOT EXISTS %DATABASE_NAME%;" >nul 2>&1
if %ERRORLEVEL% equ 0 (
    echo ✓ 数据库创建成功或已存在
) else (
    echo ✗ 数据库创建失败
    pause
    exit /b 1
)

REM 创建用户
echo 正在创建用户 '%NEW_USER'...
%MYSQL_PATH% -u %ROOT_USER% -p%ROOT_PASSWORD% -e "CREATE USER IF NOT EXISTS '%NEW_USER'@'localhost' IDENTIFIED BY '%NEW_PASSWORD';" >nul 2>&1
if %ERRORLEVEL% equ 0 (
    echo ✓ 用户创建成功或已存在
) else (
    echo ✗ 用户创建失败
    pause
    exit /b 1
)

REM 授予权限
echo 正在授予用户权限...
%MYSQL_PATH% -u %ROOT_USER% -p%ROOT_PASSWORD% -e "GRANT ALL PRIVILEGES ON %DATABASE_NAME%.* TO '%NEW_USER'@'localhost';" >nul 2>&1
%MYSQL_PATH% -u %ROOT_USER% -p%ROOT_PASSWORD% -e "FLUSH PRIVILEGES;" >nul 2>&1
if %ERRORLEVEL% equ 0 (
    echo ✓ 权限授予成功
) else (
    echo ✗ 权限授予失败
    pause
    exit /b 1
)

REM 测试新用户连接
echo 正在测试新用户连接...
%MYSQL_PATH% -u %NEW_USER% -p%NEW_PASSWORD% -D %DATABASE_NAME% -e "SELECT DATABASE();" >nul 2>&1
if %ERRORLEVEL% equ 0 (
    echo ✓ 新用户连接成功
) else (
    echo ✗ 新用户连接失败
    pause
    exit /b 1
)

echo.
echo ========================================
echo MySQL用户和数据库创建成功！
echo ========================================
echo 用户名: %NEW_USER%
echo 密码: %NEW_PASSWORD%
echo 数据库: %DATABASE_NAME%
echo ========================================
echo.
echo 现在需要更新app.py和init_db.py中的数据库连接参数。
echo 将用户名改为 '%NEW_USER'，密码改为 '%NEW_PASSWORD'
echo.
pause
