import mysql.connector
from mysql.connector import Error
import datetime

def create_connection():
    connection = None
    # 尝试不同的连接方式
    connection_options = [
        # 1. root用户，有密码（正确密码）
        {'user': 'root', 'password': '1975819cjn'},
        # 2. root用户，无密码
        {'user': 'root', 'password': ''},
        # 3. 新用户，有密码
        {'user': 'ecommerce_user', 'password': 'ecommerce123'}
    ]
    
    for option in connection_options:
        try:
            connection = mysql.connector.connect(
                host='127.0.0.1',
                port=3306,
                user=option['user'],
                password=option['password'],
                database='ecommerce_db'
            )
            if connection.is_connected():
                print(f"Successfully connected to the database with user: {option['user']}")
                return connection
        except Error as e:
            print(f"Error connecting to MySQL with user {option['user']}: {e}")
            # 如果数据库不存在，尝试创建数据库
            if "Unknown database" in str(e):
                try:
                    temp_connection = mysql.connector.connect(
                        host='127.0.0.1',
                        port=3306,
                        user=option['user'],
                        password=option['password']
                    )
                    if temp_connection.is_connected():
                        cursor = temp_connection.cursor()
                        cursor.execute("CREATE DATABASE ecommerce_db")
                        print("Database created successfully")
                        temp_connection.close()
                        # 再次尝试连接
                        return create_connection()
                except Error as e2:
                    print(f"Error creating database with user {option['user']}: {e2}")
    return connection

def create_tables():
    connection = create_connection()
    if connection and connection.is_connected():
        cursor = connection.cursor()
        
        # 创建商品分类表
        cursor.execute("""CREATE TABLE IF NOT EXISTS categories (
            category_id INT PRIMARY KEY AUTO_INCREMENT,
            category_name VARCHAR(100) NOT NULL,
            description TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )""")
        
        # 创建用户表
        cursor.execute("""CREATE TABLE IF NOT EXISTS users (
            user_id INT PRIMARY KEY AUTO_INCREMENT,
            username VARCHAR(50) UNIQUE NOT NULL,
            password VARCHAR(255) NOT NULL,
            email VARCHAR(100) UNIQUE NOT NULL,
            full_name VARCHAR(100) NOT NULL,
            phone VARCHAR(20),
            address TEXT,
            role ENUM('admin', 'customer') DEFAULT 'customer',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        )""")
        
        # 创建商品表
        cursor.execute("""CREATE TABLE IF NOT EXISTS products (
            product_id INT PRIMARY KEY AUTO_INCREMENT,
            product_name VARCHAR(200) NOT NULL,
            description TEXT,
            price DECIMAL(10, 2) NOT NULL CHECK (price > 0),
            stock_quantity INT NOT NULL CHECK (stock_quantity >= 0),
            category_id INT,
            image_url VARCHAR(255),
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            FOREIGN KEY (category_id) REFERENCES categories(category_id) ON DELETE SET NULL
        )""")
        
        # 创建订单表
        cursor.execute("""CREATE TABLE IF NOT EXISTS orders (
            order_id INT PRIMARY KEY AUTO_INCREMENT,
            user_id INT NOT NULL,
            total_amount DECIMAL(10, 2) NOT NULL CHECK (total_amount > 0),
            order_status ENUM('pending', 'processing', 'shipped', 'delivered', 'cancelled') DEFAULT 'pending',
            shipping_address TEXT NOT NULL,
            billing_address TEXT NOT NULL,
            payment_status ENUM('unpaid', 'paid', 'refunded') DEFAULT 'unpaid',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
        )""")
        
        # 创建订单商品表
        cursor.execute("""CREATE TABLE IF NOT EXISTS order_items (
            order_item_id INT PRIMARY KEY AUTO_INCREMENT,
            order_id INT NOT NULL,
            product_id INT NOT NULL,
            quantity INT NOT NULL CHECK (quantity > 0),
            unit_price DECIMAL(10, 2) NOT NULL CHECK (unit_price > 0),
            total_price DECIMAL(10, 2) NOT NULL CHECK (total_price > 0),
            FOREIGN KEY (order_id) REFERENCES orders(order_id) ON DELETE CASCADE,
            FOREIGN KEY (product_id) REFERENCES products(product_id) ON DELETE RESTRICT
        )""")
        
        # 创建支付表
        cursor.execute("""CREATE TABLE IF NOT EXISTS payments (
            payment_id INT PRIMARY KEY AUTO_INCREMENT,
            order_id INT NOT NULL,
            payment_method VARCHAR(50) NOT NULL,
            amount DECIMAL(10, 2) NOT NULL CHECK (amount > 0),
            payment_status ENUM('pending', 'completed', 'failed', 'refunded') DEFAULT 'pending',
            transaction_id VARCHAR(100),
            payment_date TIMESTAMP,
            FOREIGN KEY (order_id) REFERENCES orders(order_id) ON DELETE CASCADE
        )""")
        
        print("Tables created successfully")
        cursor.close()
        connection.close()

def insert_sample_data():
    connection = create_connection()
    if connection and connection.is_connected():
        cursor = connection.cursor()
        
        # 插入商品分类数据
        categories = [
            ("手机数码", "各种智能手机、平板电脑、数码配件等"),
            ("电脑办公", "笔记本电脑、台式机、办公设备等"),
            ("家用电器", "冰箱、洗衣机、电视等家用电器"),
            ("服装鞋帽", "男装、女装、鞋靴、配饰等"),
            ("美妆护肤", "化妆品、护肤品、个人护理用品等")
        ]
        cursor.executemany("INSERT INTO categories (category_name, description) VALUES (%s, %s)", categories)
        
        # 插入用户数据
        users = [
            ("admin", "admin123", "admin@example.com", "系统管理员", "13800138000", "北京市朝阳区", "admin"),
            ("customer1", "pass123", "customer1@example.com", "张三", "13900139001", "上海市浦东新区", "customer"),
            ("customer2", "pass456", "customer2@example.com", "李四", "13700137002", "广州市天河区", "customer"),
            ("customer3", "pass789", "customer3@example.com", "王五", "13600136003", "深圳市南山区", "customer")
        ]
        cursor.executemany("INSERT INTO users (username, password, email, full_name, phone, address, role) VALUES (%s, %s, %s, %s, %s, %s, %s)", users)
        
        # 插入商品数据
        products = [
            ("iPhone 15 Pro", "Apple iPhone 15 Pro 智能手机", 8999.00, 50, 1, "https://example.com/iphone15.jpg"),
            ("MacBook Pro", "Apple MacBook Pro 笔记本电脑", 15999.00, 30, 2, "https://example.com/macbook.jpg"),
            ("小米14", "小米14 智能手机", 3999.00, 100, 1, "https://example.com/xiaomi14.jpg"),
            ("华为Mate 60", "华为Mate 60 智能手机", 5999.00, 80, 1, "https://example.com/huawei.jpg"),
            ("格力空调", "格力 1.5匹 变频空调", 2999.00, 40, 3, "https://example.com/airconditioner.jpg"),
            ("海尔冰箱", "海尔 500升 双开门冰箱", 4599.00, 25, 3, "https://example.com/fridge.jpg"),
            ("耐克运动鞋", "耐克 Air Max 运动鞋", 899.00, 120, 4, "https://example.com/nike.jpg"),
            ("雅诗兰黛面霜", "雅诗兰黛 小棕瓶面霜", 1299.00, 60, 5, "https://example.com/estee.jpg")
        ]
        cursor.executemany("INSERT INTO products (product_name, description, price, stock_quantity, category_id, image_url) VALUES (%s, %s, %s, %s, %s, %s)", products)
        
        # 插入订单数据
        orders = [
            (2, 8999.00, "delivered", "上海市浦东新区张杨路123号", "上海市浦东新区张杨路123号", "paid"),
            (3, 4599.00, "shipped", "广州市天河区天河路456号", "广州市天河区天河路456号", "paid"),
            (2, 15999.00, "processing", "上海市浦东新区张杨路123号", "上海市浦东新区张杨路123号", "paid"),
            (4, 3999.00, "pending", "深圳市南山区科技园路789号", "深圳市南山区科技园路789号", "unpaid")
        ]
        cursor.executemany("INSERT INTO orders (user_id, total_amount, order_status, shipping_address, billing_address, payment_status) VALUES (%s, %s, %s, %s, %s, %s)", orders)
        
        # 获取订单ID
        cursor.execute("SELECT order_id FROM orders")
        order_ids = [row[0] for row in cursor.fetchall()]
        
        # 插入订单商品数据
        order_items = [
            (order_ids[0], 1, 1, 8999.00, 8999.00),  # iPhone 15 Pro
            (order_ids[1], 6, 1, 4599.00, 4599.00),  # 海尔冰箱
            (order_ids[2], 2, 1, 15999.00, 15999.00), # MacBook Pro
            (order_ids[3], 3, 1, 3999.00, 3999.00)   # 小米14
        ]
        cursor.executemany("INSERT INTO order_items (order_id, product_id, quantity, unit_price, total_price) VALUES (%s, %s, %s, %s, %s)", order_items)
        
        # 插入支付数据
        payments = [
            (order_ids[0], "支付宝", 8999.00, "completed", "alipay123456", datetime.datetime.now()),
            (order_ids[1], "微信支付", 4599.00, "completed", "wechat789012", datetime.datetime.now()),
            (order_ids[2], "信用卡", 15999.00, "completed", "credit345678", datetime.datetime.now()),
            (order_ids[3], "支付宝", 3999.00, "pending", None, None)
        ]
        cursor.executemany("INSERT INTO payments (order_id, payment_method, amount, payment_status, transaction_id, payment_date) VALUES (%s, %s, %s, %s, %s, %s)", payments)
        
        connection.commit()
        print("Sample data inserted successfully")
        cursor.close()
        connection.close()

if __name__ == "__main__":
    create_tables()
    insert_sample_data()
    print("Database initialization completed")