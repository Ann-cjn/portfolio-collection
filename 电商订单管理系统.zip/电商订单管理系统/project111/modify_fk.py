import mysql.connector

conn = mysql.connector.connect(
    host='localhost',
    user='root',
    password='1975819cjn',
    database='ecommerce_db'
)
cursor = conn.cursor()

print('修改外键约束...')

cursor.execute('ALTER TABLE order_items DROP FOREIGN KEY order_items_ibfk_2')
print('已删除旧的外键约束')

cursor.execute('ALTER TABLE order_items ADD CONSTRAINT order_items_ibfk_2 FOREIGN KEY (product_id) REFERENCES products(product_id) ON DELETE SET NULL')
print('已添加新的外键约束 (ON DELETE SET NULL)')

conn.commit()
conn.close()
print('外键约束修改成功！')
