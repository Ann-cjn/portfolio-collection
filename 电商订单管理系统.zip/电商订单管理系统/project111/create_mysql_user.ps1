# 创建MySQL用户和数据库的PowerShell脚本
# 请确保以管理员身份运行此脚本

# MySQL服务器参数
$mysqlPath = "C:\Program Files\MySQL\MySQL Server 8.0\bin\mysql.exe"
$rootUser = "root"
$rootPassword = "123456"  # 请替换为你的root密码
$newUser = "ecommerce_user"
$newPassword = "ecommerce123"
$databaseName = "ecommerce_db"

# 测试root连接
Write-Host "正在测试MySQL root连接..."
try {
    & $mysqlPath -u $rootUser -p$rootPassword -e "SELECT VERSION();" 2>$null
    if ($LASTEXITCODE -eq 0) {
        Write-Host "✓ root连接成功"
    } else {
        Write-Host "✗ root连接失败，请检查密码是否正确"
        Write-Host "请在脚本中修改rootPassword变量，然后重新运行"
        exit 1
    }
} catch {
    Write-Host "✗ 连接失败: $_"
    exit 1
}

# 创建数据库
Write-Host "正在创建数据库 '$databaseName'..."
try {
    & $mysqlPath -u $rootUser -p$rootPassword -e "CREATE DATABASE IF NOT EXISTS $databaseName;"
    if ($LASTEXITCODE -eq 0) {
        Write-Host "✓ 数据库创建成功或已存在"
    } else {
        Write-Host "✗ 数据库创建失败"
        exit 1
    }
} catch {
    Write-Host "✗ 数据库创建失败: $_"
    exit 1
}

# 创建用户
Write-Host "正在创建用户 '$newUser'..."
try {
    & $mysqlPath -u $rootUser -p$rootPassword -e "CREATE USER IF NOT EXISTS '$newUser'@'localhost' IDENTIFIED BY '$newPassword';"
    if ($LASTEXITCODE -eq 0) {
        Write-Host "✓ 用户创建成功或已存在"
    } else {
        Write-Host "✗ 用户创建失败"
        exit 1
    }
} catch {
    Write-Host "✗ 用户创建失败: $_"
    exit 1
}

# 授予权限
Write-Host "正在授予用户权限..."
try {
    & $mysqlPath -u $rootUser -p$rootPassword -e "GRANT ALL PRIVILEGES ON $databaseName.* TO '$newUser'@'localhost';"
    & $mysqlPath -u $rootUser -p$rootPassword -e "FLUSH PRIVILEGES;"
    if ($LASTEXITCODE -eq 0) {
        Write-Host "✓ 权限授予成功"
    } else {
        Write-Host "✗ 权限授予失败"
        exit 1
    }
} catch {
    Write-Host "✗ 权限授予失败: $_"
    exit 1
}

# 测试新用户连接
Write-Host "正在测试新用户连接..."
try {
    & $mysqlPath -u $newUser -p$newPassword -D $databaseName -e "SELECT DATABASE();"
    if ($LASTEXITCODE -eq 0) {
        Write-Host "✓ 新用户连接成功"
    } else {
        Write-Host "✗ 新用户连接失败"
        exit 1
    }
} catch {
    Write-Host "✗ 新用户连接失败: $_"
    exit 1
}

Write-Host ""
Write-Host "========================================"
Write-Host "MySQL用户和数据库创建成功！"
Write-Host "========================================"
Write-Host "用户名: $newUser"
Write-Host "密码: $newPassword"
Write-Host "数据库: $databaseName"
Write-Host "========================================"
Write-Host ""
Write-Host "现在需要更新app.py和init_db.py中的数据库连接参数。"
Write-Host "将用户名改为 '$newUser'，密码改为 '$newPassword'"
