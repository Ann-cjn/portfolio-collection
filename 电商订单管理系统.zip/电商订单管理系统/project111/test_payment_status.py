import mysql.connector
from mysql.connector import Error

# 创建数据库连接
def create_connection():
    connection = None
    try:
        # 首先尝试使用root用户连接（没有密码）
        connection = mysql.connector.connect(
                host='127.0.0.1',
                port=3306,
                user='root',
                database='ecommerce_db'
            )
        return connection
    except Error as e:
        print(f"First connection attempt failed: {e}")
        try:
            # 然后尝试使用root用户连接（带密码）
            connection = mysql.connector.connect(
                host='127.0.0.1',
                port=3306,
                user='root',
                password='1975819cjn',
                database='ecommerce_db'
            )
            return connection
        except Error as e2:
            print(f"Second connection attempt failed: {e2}")
            try:
                # 最后尝试使用ecommerce_user用户连接
                connection = mysql.connector.connect(
                    host='127.0.0.1',
                    port=3306,
                    user='ecommerce_user',
                    password='ecommerce123',
                    database='ecommerce_db'
                )
                return connection
            except Error as e3:
                print(f"Third connection attempt failed: {e3}")
    return None

# 查询所有订单和支付状态
def test_payment_status_filtering():
    connection = create_connection()
    if connection and connection.is_connected():
        cursor = connection.cursor(dictionary=True)
        
        print("=== 测试支付状态筛选 ===")
        
        # 查询所有支付记录
        cursor.execute("SELECT * FROM payments")
        payments = cursor.fetchall()
        print(f"\n1. 所有支付记录 ({len(payments)} 条):")
        for payment in payments:
            print(f"订单ID: {payment['order_id']}, 支付状态: {payment['payment_status']}")
        
        # 查询所有订单及其支付状态
        cursor.execute("""
            SELECT o.order_id, o.total_price, o.status, MAX(p.payment_status) as payment_status
            FROM orders o 
            LEFT JOIN payments p ON o.order_id = p.order_id
            GROUP BY o.order_id, o.total_price, o.status
        """)
        orders = cursor.fetchall()
        print(f"\n2. 所有订单及其支付状态 ({len(orders)} 条):")
        for order in orders:
            print(f"订单ID: {order['order_id']}, 状态: {order['status']}, 支付状态: {order['payment_status']}")
        
        # 测试已支付筛选
        print(f"\n3. 测试已支付筛选 (paid -> completed):")
        cursor.execute("""
            SELECT o.order_id, o.total_price, o.status, MAX(p.payment_status) as payment_status
            FROM orders o 
            LEFT JOIN payments p ON o.order_id = p.order_id
            WHERE p.payment_status = 'completed'
            GROUP BY o.order_id, o.total_price, o.status
        """)
        paid_orders = cursor.fetchall()
        print(f"已支付订单: {len(paid_orders)} 条")
        for order in paid_orders:
            print(f"订单ID: {order['order_id']}, 支付状态: {order['payment_status']}")
        
        # 测试未支付筛选
        print(f"\n4. 测试未支付筛选 (unpaid):")
        cursor.execute("""
            SELECT o.order_id, o.total_price, o.status, MAX(p.payment_status) as payment_status
            FROM orders o 
            LEFT JOIN payments p ON o.order_id = p.order_id
            WHERE p.payment_status IS NULL OR p.payment_status NOT IN ('completed', 'pending')
            GROUP BY o.order_id, o.total_price, o.status
        """)
        unpaid_orders = cursor.fetchall()
        print(f"未支付订单: {len(unpaid_orders)} 条")
        for order in unpaid_orders:
            print(f"订单ID: {order['order_id']}, 支付状态: {order['payment_status']}")
        
        # 测试已退款筛选
        print(f"\n5. 测试已退款筛选 (refunded):")
        cursor.execute("""
            SELECT o.order_id, o.total_price, o.status, MAX(p.payment_status) as payment_status
            FROM orders o 
            LEFT JOIN payments p ON o.order_id = p.order_id
            WHERE p.payment_status = 'refunded'
            GROUP BY o.order_id, o.total_price, o.status
        """)
        refunded_orders = cursor.fetchall()
        print(f"已退款订单: {len(refunded_orders)} 条")
        for order in refunded_orders:
            print(f"订单ID: {order['order_id']}, 支付状态: {order['payment_status']}")
        
        cursor.close()
        connection.close()

if __name__ == "__main__":
    test_payment_status_filtering()
