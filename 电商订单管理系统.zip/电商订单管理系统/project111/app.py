from flask import Flask, render_template, request, redirect, url_for, flash
import mysql.connector
from mysql.connector import Error
import datetime
import os

app = Flask(__name__)
app.secret_key = 'your_secret_key_here'  # 用于flash消息

# 数据库连接函数
def create_connection():
    connection = None
    try:
        # 首先尝试使用root用户连接（没有密码）
        connection = mysql.connector.connect(
                host='127.0.0.1',
                port=3306,
                user='root',
                database='ecommerce_db'
            )
        return connection
    except Error as e:
        print(f"First connection attempt failed: {e}")
        try:
            # 然后尝试使用root用户连接（带密码）
            connection = mysql.connector.connect(
                host='127.0.0.1',
                port=3306,
                user='root',
                password='1975819cjn',
                database='ecommerce_db'
            )
            return connection
        except Error as e2:
            print(f"Second connection attempt failed: {e2}")
            try:
                # 最后尝试使用ecommerce_user用户连接
                connection = mysql.connector.connect(
                    host='127.0.0.1',
                    port=3306,
                    user='ecommerce_user',
                    password='ecommerce123',
                    database='ecommerce_db'
                )
                return connection
            except Error as e3:
                print(f"Third connection attempt failed: {e3}")
    return connection

# 首页路由
@app.route('/')
def index():
    # 获取统计数据
    connection = create_connection()
    if connection and connection.is_connected():
        cursor = connection.cursor(dictionary=True)
        
        # 总订单数
        cursor.execute("SELECT COUNT(*) as total_orders FROM orders")
        total_orders = cursor.fetchone()['total_orders']
        
        # 总销售额 - 基于已完成支付的订单
        cursor.execute("""
            SELECT SUM(o.total_price) as total_sales 
            FROM orders o
            JOIN payments p ON o.order_id = p.order_id
            WHERE p.payment_status = 'completed'
        """)
        total_sales = cursor.fetchone()['total_sales'] or 0
        
        # 总用户数
        cursor.execute("SELECT COUNT(*) as total_users FROM users")
        total_users = cursor.fetchone()['total_users']
        
        # 总商品数
        cursor.execute("SELECT COUNT(*) as total_products FROM products")
        total_products = cursor.fetchone()['total_products']
        
        # 最近订单
        cursor.execute("SELECT o.order_id, u.username, o.total_price, o.status, o.order_time as order_time "
                       "FROM orders o JOIN users u ON o.user_id = u.user_id "
                       "ORDER BY o.order_time DESC LIMIT 5")
        recent_orders = cursor.fetchall()
        
        cursor.close()
        connection.close()
        
        return render_template('index.html', 
                             total_orders=total_orders, 
                             total_sales=total_sales, 
                             total_users=total_users, 
                             total_products=total_products,
                             recent_orders=recent_orders)
    # 如果数据库连接失败，使用默认值
    return render_template('index.html', 
                         total_orders=0, 
                         total_sales=0, 
                         total_users=0, 
                         total_products=0,
                         recent_orders=[])

# 商品管理路由
@app.route('/products')
def products():
    page = request.args.get('page', 1, type=int)
    per_page = 10
    offset = (page - 1) * per_page
    
    # 筛选条件
    category = request.args.get('category', '')
    search = request.args.get('search', '')
    
    # 排序条件
    sort_by = request.args.get('sort_by', 'product_id')
    order = request.args.get('order', 'asc')
    
    connection = create_connection()
    if connection and connection.is_connected():
        cursor = connection.cursor(dictionary=True)
        
        # 构建查询语句
        query = "SELECT * FROM products WHERE 1=1"
        count_query = "SELECT COUNT(*) as count FROM products WHERE 1=1"
        params = []
        
        # 添加筛选条件
        if category:
            query += " AND category = %s"
            count_query += " AND category = %s"
            params.append(category)
        
        if search:
            query += " AND name LIKE %s"
            count_query += " AND name LIKE %s"
            params.append(f"%{search}%")
        
        # 保存筛选参数用于count查询
        count_params = params.copy()
        
        # 添加排序
        valid_sort_fields = ['product_id', 'name', 'price', 'stock']
        if sort_by not in valid_sort_fields:
            sort_by = 'product_id'
        
        if order not in ['asc', 'desc']:
            order = 'asc'
        
        query += f" ORDER BY {sort_by} {order}"
        
        # 添加分页
        query += " LIMIT %s OFFSET %s"
        params.extend([per_page, offset])
        
        cursor.execute(query, params)
        products = cursor.fetchall()
        
        # 获取总记录数
        cursor.execute(count_query, count_params)
        total_records = cursor.fetchone()['count']
        total_pages = (total_records + per_page - 1) // per_page
        
        # 获取所有分类
        cursor.execute("SELECT DISTINCT category FROM products WHERE category IS NOT NULL AND category != ''")
        categories = cursor.fetchall()
        
        cursor.close()
        connection.close()
        
        return render_template('products.html', 
                             products=products,
                             categories=categories,
                             selected_category=category,
                             search=search,
                             sort_by=sort_by,
                             order=order,
                             page=page,
                             total_pages=total_pages,
                             per_page=per_page,
                             total_records=total_records)
    return render_template('products.html')

# 添加商品路由
@app.route('/add_product', methods=['GET', 'POST'])
def add_product():
    connection = create_connection()
    if connection and connection.is_connected():
        cursor = connection.cursor(dictionary=True)
        
        # 获取所有分类
        cursor.execute("SELECT DISTINCT category FROM products WHERE category IS NOT NULL AND category != ''")
        categories = cursor.fetchall()
        
        if request.method == 'POST':
            name = request.form['name']
            price = float(request.form['price'])
            stock = int(request.form['stock'])
            category = request.form['category']
            
            try:
                # 获取当前最大的product_id
                cursor.execute("SELECT MAX(product_id) as max_id FROM products")
                max_id = cursor.fetchone()['max_id']
                # 新的product_id是最大ID+1，如果没有记录则从1开始
                new_product_id = max_id + 1 if max_id else 1
                
                cursor.execute("""
                    INSERT INTO products (product_id, name, price, stock, category)
                    VALUES (%s, %s, %s, %s, %s)
                """, (new_product_id, name, price, stock, category))
                connection.commit()
                flash('商品添加成功！')
                return redirect(url_for('products'))
            except Error as e:
                connection.rollback()
                flash(f'添加失败: {str(e)}')
        
        cursor.close()
        connection.close()
        
        return render_template('add_product.html', categories=categories)
    return redirect(url_for('products'))

# 编辑商品路由
@app.route('/edit_product/<int:product_id>', methods=['GET', 'POST'])
def edit_product(product_id):
    connection = create_connection()
    if connection and connection.is_connected():
        cursor = connection.cursor(dictionary=True)
        
        # 获取所有分类
        cursor.execute("SELECT DISTINCT category FROM products WHERE category IS NOT NULL AND category != ''")
        categories = cursor.fetchall()
        
        if request.method == 'POST':
            name = request.form['name']
            price = float(request.form['price'])
            stock = int(request.form['stock'])
            category = request.form['category']
            
            try:
                cursor.execute("""
                    UPDATE products SET name = %s, price = %s, stock = %s, category = %s
                    WHERE product_id = %s
                """, (name, price, stock, category, product_id))
                connection.commit()
                flash('商品更新成功！')
                return redirect(url_for('products'))
            except Error as e:
                connection.rollback()
                flash(f'更新失败: {str(e)}')
        else:
            # 获取商品信息
            cursor.execute("SELECT * FROM products WHERE product_id = %s", (product_id,))
            product = cursor.fetchone()
            
            if product:
                return render_template('edit_product.html', product=product, categories=categories)
            else:
                flash('商品不存在！')
        
        cursor.close()
        connection.close()
    return redirect(url_for('products'))

# 删除商品路由
@app.route('/delete_product/<int:product_id>')
def delete_product(product_id):
    connection = create_connection()
    if connection and connection.is_connected():
        cursor = connection.cursor()
        
        try:
            # 先保存商品名称到订单商品表
            cursor.execute("UPDATE order_items oi JOIN products p ON oi.product_id = p.product_id SET oi.product_name = p.name WHERE oi.product_id = %s", (product_id,))
            # 删除商品（外键约束会自动将order_items中的product_id设为NULL）
            cursor.execute("DELETE FROM products WHERE product_id = %s", (product_id,))
            connection.commit()
            flash('商品删除成功！订单记录已保留商品信息。')
        except Error as e:
            connection.rollback()
            flash(f'删除失败: {str(e)}')
        
        cursor.close()
        connection.close()
    return redirect(url_for('products'))

# 订单管理路由
@app.route('/orders')
def orders():
    page = request.args.get('page', 1, type=int)
    per_page = 10
    offset = (page - 1) * per_page
    
    # 筛选条件
    order_status = request.args.get('order_status')
    payment_status = request.args.get('payment_status')
    user_id = request.args.get('user_id', type=int)
    product_category = request.args.get('product_category')
    
    connection = create_connection()
    if connection and connection.is_connected():
        cursor = connection.cursor(dictionary=True)
        
        # 构建查询语句
        query = """SELECT o.order_id, o.user_id, o.total_price, o.status, o.order_time, o.shipping_address, o.billing_address, 
                 u.username as user_name, 
                 CASE 
                     WHEN COUNT(oi.item_id) = 0 THEN '商品已下架'
                     ELSE COALESCE(
                         GROUP_CONCAT(
                             CASE 
                                 WHEN pr.product_id IS NULL THEN CONCAT(COALESCE(oi.product_name, pr.name), '（已下架）')
                                 ELSE COALESCE(oi.product_name, pr.name)
                             END
                             SEPARATOR ', '
                         ), 
                         '商品已下架'
                     )
                 END as order_products, 
                 MAX(p.payment_status) as payment_status
                 FROM orders o 
                 JOIN users u ON o.user_id = u.user_id 
                 LEFT JOIN payments p ON o.order_id = p.order_id
                 LEFT JOIN order_items oi ON o.order_id = oi.order_id
                 LEFT JOIN products pr ON oi.product_id = pr.product_id
                 WHERE 1=1"""
        count_query = "SELECT COUNT(*) as count FROM orders o WHERE 1=1"
        params = []
        count_params = []
        
        # 添加商品种类筛选条件
        if product_category:
            query += " AND pr.category = %s"
            count_query += " AND EXISTS (SELECT 1 FROM order_items oi JOIN products pr ON oi.product_id = pr.product_id WHERE oi.order_id = o.order_id AND pr.category = %s)"
            params.append(product_category)  # 主查询的参数
            count_params.append(product_category)  # 计数查询的参数
        
        # 添加订单状态筛选条件
        if order_status:
            # 处理订单状态的中英文映射
            if order_status == 'pending':
                query += " AND (o.status = 'pending' OR o.status = '待处理')"
                count_query += " AND (o.status = 'pending' OR o.status = '待处理')"
            elif order_status == 'processing':
                query += " AND (o.status = 'processing' OR o.status = '处理中')"
                count_query += " AND (o.status = 'processing' OR o.status = '处理中')"
            elif order_status == 'shipped':
                query += " AND (o.status = 'shipped' OR o.status = '已发货')"
                count_query += " AND (o.status = 'shipped' OR o.status = '已发货')"
            elif order_status == 'delivered':
                query += " AND (o.status = 'delivered' OR o.status = '已送达')"
                count_query += " AND (o.status = 'delivered' OR o.status = '已送达')"
            elif order_status == 'cancelled':
                query += " AND (o.status = 'cancelled' OR o.status = '已取消')"
                count_query += " AND (o.status = 'cancelled' OR o.status = '已取消')"
            else:
                query += " AND o.status = %s"
                count_query += " AND o.status = %s"
                params.append(order_status)
                count_params.append(order_status)
        
        # 添加用户筛选条件
        if user_id:
            query += " AND o.user_id = %s"
            count_query += " AND o.user_id = %s"
            params.append(user_id)
            count_params.append(user_id)
        
        # 添加支付状态筛选条件
        if payment_status:
            # 处理支付状态的映射
            if payment_status == 'paid':
                # 映射'paid'到'completed'，因为数据库中存储的是'completed'
                mapped_status = 'completed'
            elif payment_status == 'unpaid':
                # 未支付的情况，需要处理没有支付记录的订单
                query += " AND (p.payment_status IS NULL OR p.payment_status NOT IN ('completed', 'pending'))"
                count_query += " AND NOT EXISTS (SELECT 1 FROM payments WHERE order_id = o.order_id AND payment_status IN ('completed', 'pending'))"
            elif payment_status == 'refunded':
                # 处理已退款状态
                mapped_status = 'refunded'
            else:
                mapped_status = payment_status
                
            if payment_status != 'unpaid':
                query += " AND p.payment_status = %s"
                count_query += " AND EXISTS (SELECT 1 FROM payments WHERE order_id = o.order_id AND payment_status = %s)"
                params.append(mapped_status)
                count_params.append(mapped_status)
        
        # 添加分组
        query += " GROUP BY o.order_id, o.user_id, o.total_price, o.status, o.order_time, o.shipping_address, o.billing_address, u.username"
        
        # 移除count_params复制，因为我们已经在每个筛选条件中分别维护了count_params
        
        # 按创建时间降序排序
        query += " ORDER BY o.order_time DESC"
        
        # 添加分页
        query += " LIMIT %s OFFSET %s"
        params.extend([per_page, offset])
        
        cursor.execute(query, params)
        orders = cursor.fetchall()
        
        # 获取总记录数
        cursor.execute(count_query, count_params)
        total_records = cursor.fetchone()['count']
        total_pages = (total_records + per_page - 1) // per_page
        
        # 获取所有用户（排除admin）
        cursor.execute("SELECT user_id, username FROM users WHERE username != 'admin'")
        users = cursor.fetchall()
        
        # 获取所有商品种类
        cursor.execute("SELECT DISTINCT category FROM products")
        product_categories = [row['category'] for row in cursor.fetchall()]
        
        cursor.close()
        connection.close()
        
        return render_template('orders.html', 
                             orders=orders,
                             order_status=order_status,
                             payment_status=payment_status,
                             user_id=user_id,
                             product_category=product_category,
                             users=users,
                             product_categories=product_categories,
                             page=page,
                             total_pages=total_pages,
                             per_page=per_page,
                             total_records=total_records)
    return render_template('orders.html')

# 订单详情路由
@app.route('/order_details/<int:order_id>')
def order_details(order_id):
    connection = create_connection()
    if connection and connection.is_connected():
        cursor = connection.cursor(dictionary=True)
        
        # 获取订单信息和用户地址
        cursor.execute("SELECT o.*, u.username as user_name, u.phone, u.address as user_address FROM orders o JOIN users u ON o.user_id = u.user_id WHERE o.order_id = %s", (order_id,))
        order = cursor.fetchone()
        
        if order:
            # 如果订单的收货地址为空，使用用户的地址
            if not order['shipping_address'] and order['user_address']:
                order['shipping_address'] = order['user_address']
            
            # 获取订单商品（使用LEFT JOIN，优先显示order_items中保存的商品名称）
            cursor.execute("SELECT oi.*, COALESCE(oi.product_name, p.name) as name, p.product_id as product_exists FROM order_items oi LEFT JOIN products p ON oi.product_id = p.product_id WHERE oi.order_id = %s", (order_id,))
            order_items = cursor.fetchall()
            
            # 获取支付信息
            cursor.execute("SELECT * FROM payments WHERE order_id = %s", (order_id,))
            payment = cursor.fetchone()
            
            cursor.close()
            connection.close()
            
            return render_template('order_details.html', order=order, order_items=order_items, payment=payment)
        else:
            cursor.close()
            connection.close()
            flash('订单不存在！')
    return redirect(url_for('orders'))

# 更新订单状态路由
@app.route('/update_order_status/<int:order_id>', methods=['POST'])
def update_order_status(order_id):
    new_status = request.form['order_status']
    
    connection = create_connection()
    if connection and connection.is_connected():
        cursor = connection.cursor()
        
        try:
            cursor.execute("UPDATE orders SET status = %s WHERE order_id = %s", (new_status, order_id))
            connection.commit()
            flash('订单状态更新成功！')
        except Error as e:
            connection.rollback()
            flash(f'更新失败: {str(e)}')
        
        cursor.close()
        connection.close()
    return redirect(url_for('order_details', order_id=order_id))

# 用户管理路由
@app.route('/users')
def users():
    page = request.args.get('page', 1, type=int)
    per_page = 10
    offset = (page - 1) * per_page
    
    # 筛选条件
    search_username = request.args.get('search_username', '')
    search_phone = request.args.get('search_phone', '')
    search_address = request.args.get('search_address', '')
    
    connection = create_connection()
    if connection and connection.is_connected():
        cursor = connection.cursor(dictionary=True)
        
        # 构建查询语句
        query = "SELECT * FROM users WHERE 1=1"
        count_query = "SELECT COUNT(*) as count FROM users WHERE 1=1"
        params = []
        
        # 添加搜索条件
        if search_username:
            # 尝试将搜索值转换为整数（用户ID）
            try:
                user_id = int(search_username)
                # 同时搜索用户名和用户ID
                query += " AND (username LIKE %s OR user_id = %s)"
                count_query += " AND (username LIKE %s OR user_id = %s)"
                params.append(f"%{search_username}%")
                params.append(user_id)
            except ValueError:
                # 如果不是整数，只搜索用户名
                query += " AND username LIKE %s"
                count_query += " AND username LIKE %s"
                params.append(f"%{search_username}%")
        
        # 搜索电话
        if search_phone:
            query += " AND phone LIKE %s"
            count_query += " AND phone LIKE %s"
            params.append(f"%{search_phone}%")
        
        # 搜索地址
        if search_address:
            query += " AND address LIKE %s"
            count_query += " AND address LIKE %s"
            params.append(f"%{search_address}%")
        
        # 保存筛选参数用于count查询
        count_params = params.copy()
        
        # 按ID升序排序
        query += " ORDER BY user_id ASC"
        
        # 添加分页
        query += " LIMIT %s OFFSET %s"
        params.extend([per_page, offset])
        
        cursor.execute(query, params)
        users_list = cursor.fetchall()
        
        # 获取总记录数
        cursor.execute(count_query, count_params)
        total_records = cursor.fetchone()['count']
        total_pages = (total_records + per_page - 1) // per_page
        
        cursor.close()
        connection.close()
        
        return render_template('users.html', 
                             users=users_list,
                             search_username=search_username,
                             search_phone=search_phone,
                             search_address=search_address,
                             page=page,
                             total_pages=total_pages,
                             per_page=per_page,
                             total_records=total_records)
    return render_template('users.html')

# 添加用户路由
@app.route('/add_user', methods=['GET', 'POST'])
def add_user():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        phone = request.form['phone']
        address = request.form['address']
        
        connection = create_connection()
        if connection and connection.is_connected():
            cursor = connection.cursor()
            
            try:
                # 查询现有用户ID，找出最小的空缺ID
                cursor.execute("SELECT user_id FROM users ORDER BY user_id ASC")
                existing_ids = [row[0] for row in cursor.fetchall()]
                
                # 查找最小的空缺ID
                new_user_id = None
                if not existing_ids:
                    # 如果没有用户，使用1作为第一个ID
                    new_user_id = 1
                else:
                    # 检查是否有1到max_id之间的空缺
                    max_id = existing_ids[-1]
                    for i in range(1, max_id + 2):
                        if i not in existing_ids:
                            new_user_id = i
                            break
                
                # 插入新用户，显式指定user_id
                sql = "INSERT INTO users (user_id, username, password, phone, address) VALUES (%s, %s, %s, %s, %s)"
                cursor.execute(sql, (new_user_id, username, password, phone, address))
                connection.commit()
                flash('用户添加成功！')
                return redirect(url_for('users'))
            except Error as e:
                connection.rollback()
                flash(f'添加失败: {str(e)}')
            
            cursor.close()
            connection.close()
    
    return render_template('add_user.html')

# 编辑用户路由
@app.route('/edit_user/<int:user_id>', methods=['GET', 'POST'])
def edit_user(user_id):
    connection = create_connection()
    if connection and connection.is_connected():
        cursor = connection.cursor(dictionary=True)
        
        if request.method == 'POST':
            username = request.form['username']
            phone = request.form['phone']
            address = request.form['address']
            
            try:
                # 更新用户信息（不处理密码和email字段）
                cursor.execute("""
                    UPDATE users SET username = %s, phone = %s, address = %s
                    WHERE user_id = %s
                """, (username, phone, address, user_id))
                
                connection.commit()
                flash('用户更新成功！')
                return redirect(url_for('users'))
            except Error as e:
                connection.rollback()
                flash(f'更新失败: {str(e)}')
        else:
            # 获取用户信息
            cursor.execute("SELECT * FROM users WHERE user_id = %s", (user_id,))
            user = cursor.fetchone()
            
            if user:
                return render_template('edit_user.html', user=user)
            else:
                flash('用户不存在！')
        
        cursor.close()
        connection.close()
    return redirect(url_for('users'))

# 删除用户路由
@app.route('/delete_user/<int:user_id>')
def delete_user(user_id):
    connection = create_connection()
    if connection and connection.is_connected():
        cursor = connection.cursor()
        
        try:
            cursor.execute("DELETE FROM users WHERE user_id = %s", (user_id,))
            connection.commit()
            flash('用户删除成功！')
        except Error as e:
            connection.rollback()
            flash(f'删除失败: {str(e)}')
        
        cursor.close()
        connection.close()
    return redirect(url_for('users'))

# 支付管理路由
@app.route('/payments')
def payments():
    page = request.args.get('page', 1, type=int)
    per_page = 10
    offset = (page - 1) * per_page
    
    # 筛选条件
    payment_method = request.args.get('payment_method')
    payment_status = request.args.get('payment_status')
    
    connection = create_connection()
    if connection and connection.is_connected():
        cursor = connection.cursor(dictionary=True)
        
        # 构建查询语句，添加商品信息，处理未支付订单的显示
        query = """SELECT o.order_id, p.payment_id, 
               COALESCE(p.payment_method, '未支付') as payment_method, 
               CASE 
                   WHEN p.payment_status = 'completed' THEN '已支付' 
                   WHEN p.payment_status IS NULL THEN '未支付'
                   ELSE p.payment_status 
               END as payment_status, 
               COALESCE(p.amount, o.total_price) as amount, 
               p.payment_date, u.username as user_name,
               GROUP_CONCAT(
                   CASE 
                       WHEN pr.product_id IS NULL THEN CONCAT(COALESCE(oi.product_name, '未知商品'), '（已下架）')
                       ELSE COALESCE(oi.product_name, pr.name)
                   END
                   SEPARATOR ', '
               ) as order_products
               FROM orders o 
               LEFT JOIN payments p ON o.order_id = p.order_id 
               JOIN users u ON o.user_id = u.user_id
               LEFT JOIN order_items oi ON o.order_id = oi.order_id
               LEFT JOIN products pr ON oi.product_id = pr.product_id
               WHERE 1=1"""
        count_query = "SELECT COUNT(*) as count FROM orders o WHERE 1=1"
        
        # 分别维护查询参数和计数参数
        query_params = []
        count_query_params = []
        
        # 添加payment_method条件
        if payment_method:
            query += " AND EXISTS (SELECT 1 FROM payments WHERE order_id = o.order_id AND payment_method = %s)"
            query += " AND p.payment_method = %s"
            count_query += " AND EXISTS (SELECT 1 FROM payments WHERE order_id = o.order_id AND payment_method = %s)"
            query_params.append(payment_method)
            query_params.append(payment_method)
            count_query_params.append(payment_method)
        
        if payment_status:
            if payment_status == 'unpaid':
                # 未支付：没有支付记录或支付状态不为completed
                query += " AND (p.payment_id IS NULL OR p.payment_status != 'completed')"
                count_query += " AND NOT EXISTS (SELECT 1 FROM payments WHERE order_id = o.order_id AND payment_status = 'completed')"
            else:
                # 其他支付状态：需要有支付记录
                query += " AND EXISTS (SELECT 1 FROM payments WHERE order_id = o.order_id AND payment_status = %s)"
                query += " AND p.payment_status = %s"
                count_query += " AND EXISTS (SELECT 1 FROM payments WHERE order_id = o.order_id AND payment_status = %s)"
                query_params.append(payment_status)
                query_params.append(payment_status)
                count_query_params.append(payment_status)
        
        # 添加GROUP BY
        query += " GROUP BY o.order_id, p.payment_id, p.payment_method, p.payment_status, p.amount, p.payment_date, u.username"
        
        # 按支付ID升序排序
        query += " ORDER BY p.payment_id ASC"
        
        # 保存筛选参数用于count查询（在添加分页参数之前）
        count_params = count_query_params.copy()
        
        # 添加分页
        query += " LIMIT %s OFFSET %s"
        query_params.extend([per_page, offset])
        
        cursor.execute(query, query_params)
        payments_list = cursor.fetchall()
        
        # 获取总记录数
        cursor.execute(count_query, count_params)
        total_records = cursor.fetchone()['count']
        total_pages = (total_records + per_page - 1) // per_page
        
        cursor.close()
        connection.close()
        
        return render_template('payments.html', 
                             payments=payments_list,
                             payment_method=payment_method,
                             payment_status=payment_status,
                             page=page,
                             total_pages=total_pages,
                             per_page=per_page,
                             total_records=total_records)
    return render_template('payments.html')

# 统计分析路由
@app.route('/statistics')
def statistics():
    connection = create_connection()
    if connection and connection.is_connected():
        cursor = connection.cursor(dictionary=True)
        
        # 1. 商品分类统计
        cursor.execute("""SELECT category, COUNT(product_id) as product_count FROM products 
                       WHERE category IS NOT NULL AND category != ''
                       GROUP BY category ORDER BY product_count DESC""")
        category_stats = cursor.fetchall()
        
        # 2. 月度销售统计 - 基于支付时间，与支付管理一致
        cursor.execute("""SELECT DATE_FORMAT(p.payment_date, '%Y-%m') as month, 
                       SUM(p.amount) as sales_amount, COUNT(DISTINCT p.order_id) as order_count 
                       FROM payments p
                       WHERE p.payment_status = 'completed'
                       GROUP BY DATE_FORMAT(p.payment_date, '%Y-%m') 
                       ORDER BY month DESC""")
        monthly_sales = cursor.fetchall()
        
        # 3. 订单状态统计
        cursor.execute("""SELECT 
                            CASE status 
                                WHEN 'pending' THEN '待处理'
                                WHEN 'processing' THEN '处理中'
                                WHEN 'shipped' THEN '已发货'
                                WHEN 'delivered' THEN '已送达'
                                WHEN 'cancelled' THEN '已取消'
                                ELSE status 
                            END as status, 
                            COUNT(*) as count 
                        FROM orders 
                        GROUP BY CASE status 
                                WHEN 'pending' THEN '待处理'
                                WHEN 'processing' THEN '处理中'
                                WHEN 'shipped' THEN '已发货'
                                WHEN 'delivered' THEN '已送达'
                                WHEN 'cancelled' THEN '已取消'
                                ELSE status 
                            END""")
        order_status_stats = cursor.fetchall()
        
        # 4. 支付方式统计 - 与支付管理完全一致
        cursor.execute("""SELECT payment_method, COUNT(*) as count, SUM(amount) as total_amount 
                       FROM payments WHERE payment_status = 'completed' 
                       GROUP BY payment_method ORDER BY total_amount DESC""")
        payment_method_stats = cursor.fetchall()
        
        # 5. 热销商品 - 处理已下架商品，使用order_items中保存的商品名称
        cursor.execute("""SELECT 
                       COALESCE(oi.product_name, p.name) as name,
                       SUM(oi.quantity) as total_sold, 
                       SUM(oi.price * oi.quantity) as total_revenue,
                       CASE WHEN p.product_id IS NULL THEN '已下架' ELSE '在售' END as status
                       FROM order_items oi 
                       LEFT JOIN products p ON oi.product_id = p.product_id 
                       JOIN orders o ON oi.order_id = o.order_id 
                       JOIN payments pay ON o.order_id = pay.order_id
                       WHERE pay.payment_status = 'completed'
                       GROUP BY COALESCE(oi.product_name, p.name), p.product_id
                       ORDER BY total_sold DESC 
                       LIMIT 10""")
        top_products = cursor.fetchall()
        
        cursor.close()
        connection.close()
        
        return render_template('statistics.html', 
                             category_stats=category_stats,
                             monthly_sales=monthly_sales,
                             order_status_stats=order_status_stats,
                             payment_method_stats=payment_method_stats,
                             top_products=top_products)
    return render_template('statistics.html')

if __name__ == '__main__':
    # 创建templates目录（如果不存在）
    if not os.path.exists('templates'):
        os.makedirs('templates')
    app.run(debug=True, host='0.0.0.0', port=5001)