<template>
  <div id="app">
    <!-- 并排显示两个组件，保留实验样式 -->
    <div class="experiment-container">
      <GuessNumberComposition />
      <GuessNumberOptions />
    </div>
  </div>
</template>

<script setup>
import GuessNumberComposition from './components/GuessNumberComposition.vue';
import GuessNumberOptions from './components/GuessNumberOptions.vue';
</script>

<style>
/* 仅控制并排布局，不修改实验样式 */
#app {
  background-color: #f0f8ff;
  min-height: 100vh;
  padding: 20px;
}
.experiment-container {
  display: flex;
  justify-content: center;
  gap: 40px;
  flex-wrap: wrap;
  max-width: 1200px;
  margin: 0 auto;
}
</style>