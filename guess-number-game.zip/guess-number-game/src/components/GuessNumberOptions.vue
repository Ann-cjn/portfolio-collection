<template>
  <!-- 完全复刻实验步骤1.2的HTML结构 -->
  <div> 
    <h2>猜数游戏（选项式API）</h2> 
    <strong>请输入一个0-100 之间的随机整数:</strong> 
    <br/><br/> 
    <form> 
      <!-- 输入框：id=guess，与实验一致 -->
      <input type="text" id="guess" v-model.number="guessValue" placeholder="输入你的猜测" :disabled="!flag"/> 
      <!-- 提交按钮：id=button，与实验一致 -->
      <input type="button" id="button" value="提交" @click="run" :disabled="!flag"/> 
      <!-- 开始按钮：与实验一致 -->
      <input type="button" value="开始" @click="restart"/> 
      <br/> 
      <!-- 结果反馈框：id=feedback，与实验一致 -->
      <label>结果: <input type="text" id="feedback" v-model="feedback" readonly/></label> 
      <!-- 剩余次数框：id=count，与实验一致 -->
      <label>当前还可以猜测的次数: <input type="text" id="count" v-model="count" readonly/></label> 
    </form> 
  </div>
</template>

<script>
export default {
  name: 'GuessNumberOptions',
  // 实验步骤3.1的变量
  data() {
    return {
      guessValue: null,
      count: 10,
      target: 0,
      flag: false,
      feedback: ''
    }
  },
  // 实验步骤3.2的restart函数
  methods: {
    restart() {
      this.flag = true;
      this.guessValue = null;
      this.feedback = '';
      this.count = 10;
      this.target = Math.floor(Math.random() * 101);
      console.log('选项式API-目标数字：', this.target);
    },
    // 实验步骤4.1的run函数
    run() {
      if (!this.flag) return;
      const guess = this.guessValue;

      // 实验的输入验证逻辑
      if (isNaN(guess) || guess < 0 || guess > 100) { 
        this.feedback = "请输入一个0-100 之间的有效数字!"; 
        return;
      }

      // 实验的结果反馈逻辑
      if (guess > this.target) { 
        this.feedback = "猜的有点大!"; 
      } else if (guess < this.target) { 
        this.feedback = "猜的有点小!"; 
      } else if (guess === this.target) { 
        this.feedback = "猜对啦!答案是" + guess; 
        this.flag = false; 
      }

      // 实验的次数更新逻辑
      this.count -= 1; 

      // 实验的次数用尽逻辑
      if (this.count === 0 && guess !== this.target) { 
        this.feedback = "游戏结束!次数已用完,正确答案是" + this.target; 
        this.flag = false; 
      }

      this.guessValue = null;
    }
  }
};
</script>

<style scoped>
/* 完全复刻实验步骤2.1的CSS样式 */
body { 
  text-align: center; 
  font-family: Arial, sans-serif; 
  background-color: #f0f8ff; 
  margin: 0; 
  padding: 0; 
  display: flex; 
  justify-content: center; 
  align-items: center; 
  height: 100vh; 
}
h2 {
  color: #333; 
}
form { 
  display: inline-block; 
  padding: 20px; 
  background-color: #fff; 
  border-radius: 10px; 
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); 
}
input[type="text"] { 
  padding: 5px; 
  margin-bottom: 10px; 
  width: 100px; 
  text-align: center; 
  border-radius: 5px; 
  border: 1px solid #ccc; 
}
input[type="button"] { 
  padding: 5px 10px; 
  margin: 5px; 
  border-radius: 5px; 
  border: 1px solid #007BFF; 
  background-color: #007BFF; 
  color: white; 
  cursor: pointer; 
}
input[type="button"]:hover { 
  background-color: #0056b3; 
}
input[type="button"]:disabled {
  background-color: #ccc;
  border-color: #ccc;
  cursor: not-allowed;
}
label { 
  display: block; 
  margin: 10px 0; 
}
</style>