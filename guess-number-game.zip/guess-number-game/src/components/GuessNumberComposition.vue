<template>
  <!-- 完全复刻实验步骤1.2的HTML结构 -->
  <div> 
    <h2>猜数游戏（组合式API）</h2> 
    <strong>请输入一个0-100 之间的随机整数:</strong> 
    <br/><br/> 
    <form> 
      <!-- 输入框：id=guess，与实验一致 -->
      <input type="text" id="guess" v-model.number="guessValue" placeholder="输入你的猜测" :disabled="!isGameActive"/> 
      <!-- 提交按钮：id=button，与实验一致 -->
      <input type="button" id="button" value="提交" @click="handleSubmit" :disabled="!isGameActive"/> 
      <!-- 开始按钮：与实验一致 -->
      <input type="button" value="开始" @click="initGame"/> 
      <br/> 
      <!-- 结果反馈框：id=feedback，与实验一致 -->
      <label>结果: <input type="text" id="feedback" v-model="feedback" readonly/></label> 
      <!-- 剩余次数框：id=count，与实验一致 -->
      <label>当前还可以猜测的次数: <input type="text" id="count" v-model="remainingCount" readonly/></label> 
    </form> 
  </div>
</template>

<script setup>
import { ref } from 'vue';

// 实验步骤3.1的变量（响应式）
const guessValue = ref(null);
const remainingCount = ref(10);
const targetNumber = ref(0);
const isGameActive = ref(false);
const feedback = ref('');

// 实验步骤3.2的restart函数
const initGame = () => {
  isGameActive.value = true;
  guessValue.value = null;
  feedback.value = '';
  remainingCount.value = 10;
  targetNumber.value = Math.floor(Math.random() * 101);
  console.log('组合式API-目标数字：', targetNumber.value);
};

// 实验步骤4.1的run函数
const handleSubmit = () => {
  if (!isGameActive.value) return;
  const guess = guessValue.value;

  // 实验的输入验证逻辑
  if (isNaN(guess) || guess < 0 || guess > 100) { 
    feedback.value = "请输入一个0-100 之间的有效数字!"; 
    return;
  }

  // 实验的结果反馈逻辑
  if (guess > targetNumber.value) { 
    feedback.value = "猜的有点大!"; 
  } else if (guess < targetNumber.value) { 
    feedback.value = "猜的有点小!"; 
  } else if (guess === targetNumber.value) { 
    feedback.value = "猜对啦!答案是" + guess; 
    isGameActive.value = false; 
  }

  // 实验的次数更新逻辑
  remainingCount.value -= 1; 

  // 实验的次数用尽逻辑
  if (remainingCount.value === 0 && guess !== targetNumber.value) { 
    feedback.value = "游戏结束!次数已用完,正确答案是" + targetNumber.value; 
    isGameActive.value = false; 
  }

  guessValue.value = null;
};
</script>

<style scoped>
/* 完全复刻实验步骤2.1的CSS样式 */
body { 
  text-align: center; 
  font-family: Arial, sans-serif; 
  background-color: #f0f8ff; 
  margin: 0; 
  padding: 0; 
  display: flex; 
  justify-content: center; 
  align-items: center; 
  height: 100vh; 
}
h2 {
  color: #333; 
}
form { 
  display: inline-block; 
  padding: 20px; 
  background-color: #fff; 
  border-radius: 10px; 
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); 
}
input[type="text"] { 
  padding: 5px; 
  margin-bottom: 10px; 
  width: 100px; 
  text-align: center; 
  border-radius: 5px; 
  border: 1px solid #ccc; 
}
input[type="button"] { 
  padding: 5px 10px; 
  margin: 5px; 
  border-radius: 5px; 
  border: 1px solid #007BFF; 
  background-color: #007BFF; 
  color: white; 
  cursor: pointer; 
}
input[type="button"]:hover { 
  background-color: #0056b3; 
}
input[type="button"]:disabled {
  background-color: #ccc;
  border-color: #ccc;
  cursor: not-allowed;
}
label { 
  display: block; 
  margin: 10px 0; 
}
</style>