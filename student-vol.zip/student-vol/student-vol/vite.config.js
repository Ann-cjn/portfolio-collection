import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'
import fs from 'fs'
import path from 'path'

function mockPlugin() {
  return {
    name: 'simple-mock-plugin',
    configureServer(server) {
      server.middlewares.use((req, res, next) => {
        const sendJSON = (file) => {
          const filePath = path.resolve(process.cwd(), `mock/${file}`)
          if (!fs.existsSync(filePath)) {
            res.statusCode = 404
            res.setHeader('Content-Type', 'application/json')
            // 优化点：避免模板字符串语法错误（原代码多了个`${file}`冗余）
            return res.end(JSON.stringify({ error: `Mock file not found: ${file}` }))
          }
          const json = fs.readFileSync(filePath, 'utf-8')
          res.setHeader('Content-Type', 'application/json')
          res.end(json)
        }

        // 处理/api/studentList请求
        if (req.url === '/api/studentList' && req.method === 'GET') {
          return sendJSON('data.json')
        }
        // 新增：处理/api/userInfo请求
        if (req.url === '/api/userInfo' && req.method === 'GET') {
          return sendJSON('userInfo.json')
        }
        // 整合图片内容：用startsWith匹配/api/actList请求
        if (req.url.startsWith('/api/actList') && req.method === 'GET') {
          return sendJSON('actList.json')
        }
        // 新增：处理/api/userInfo/submit请求
        if (req.url === '/api/userInfo/submit' && req.method === 'POST') {
          return sendJSON('success.json')
        }
        // 新增：处理积分总览请求
        if (req.url.startsWith('/api/report/myOverview') && req.method === 'GET') {
          return sendJSON('scoreOverview.json')
        }
        // 新增：处理排名列表请求
        if (req.url.startsWith('/api/report/rankList') && req.method === 'GET') {
          return sendJSON('rank.json')
        }
        // 新增：处理/addUser请求（对应控制台404错误）
        if (req.url === '/addUser' && req.method === 'POST') {
          return sendJSON('addUser.json')
        }
        // 新增：处理活动详情接口（对应图片内容）
        if (req.url.startsWith('/api/actDetails') && req.method === 'GET') {
          // 获取URL参数中的ID和status
          const url = new URL(req.url, 'http://localhost');
          const id = url.searchParams.get('id');
          const status = url.searchParams.get('status'); // 获取筛选状态参数
          
          console.log('请求参数:', { id, status }); // 添加调试日志
          
          // 加载基础详情数据
          const filePath = path.resolve(process.cwd(), `mock/actDetails.json`);
          if (!fs.existsSync(filePath)) {
            res.statusCode = 404;
            res.setHeader('Content-Type', 'application/json');
            return res.end(JSON.stringify({ error: `Mock file not found: actDetails.json` }));
          }
          
          const jsonData = JSON.parse(fs.readFileSync(filePath, 'utf-8'));
          
          // 从详情数组中找到对应ID的活动
          const requestedId = parseInt(id || 0);
          const detailItem = jsonData.data.details.find(item => item.id === requestedId) || jsonData.data.details[0];
          
          // 加载我的报名列表，获取申请状态
          const myApplyFilePath = path.resolve(process.cwd(), `mock/myApplyList.json`);
          let applyStatus = detailItem.applyStatus; // 默认状态
          
          if (fs.existsSync(myApplyFilePath)) {
            const myApplyData = JSON.parse(fs.readFileSync(myApplyFilePath, 'utf-8'));
            
            // 先尝试根据ID查找项目，但不指定状态
            const idMatch = myApplyData.data.list.find(item => item.id == id);
            console.log(`根据ID找到的项目:`, idMatch); // 添加调试日志
            
            if (status && status !== '') {
              // 如果提供了状态参数，尝试匹配ID和状态
              const statusNum = parseInt(status);
              console.log(`过滤条件: applyStatus === ${statusNum}`); // 添加调试日志
              
              // 筛选出匹配状态的项目
              const statusMatches = myApplyData.data.list.filter(item => item.applyStatus === statusNum);
              console.log(`匹配状态的项目数量: ${statusMatches.length}`); // 添加调试日志
              
              // 查找同时匹配ID和状态的项目
              const actItem = statusMatches.find(item => item.id == id);
              if (actItem) {
                console.log(`找到同时匹配ID和状态的项目:`, { id: actItem.id, applyStatus: actItem.applyStatus }); // 添加调试日志
                applyStatus = actItem.applyStatus;
              } else {
                console.log(`未找到同时匹配ID和状态的项目，使用第一个匹配ID的项目`); // 添加调试日志
                if (idMatch) {
                  applyStatus = idMatch.applyStatus;
                  console.log(`使用第一个匹配ID的项目:`, { id: idMatch.id, applyStatus: idMatch.applyStatus }); // 添加调试日志
                }
              }
            } else {
              // 未提供状态参数，直接使用匹配ID的项目
              if (idMatch) {
                console.log(`直接使用匹配ID的项目:`, { id: idMatch.id, applyStatus: idMatch.applyStatus }); // 添加调试日志
                applyStatus = idMatch.applyStatus;
              }
            }
          }
          
          // 更新详情数据中的申请状态
          const response = {
            error: 0,
            data: {
              details: {
                ...detailItem,
                applyStatus: applyStatus // 使用从myApplyList中获取的状态
              }
            }
          };
          
          console.log(`返回状态:`, applyStatus); // 添加调试日志
          
          res.setHeader('Content-Type', 'application/json');
          res.end(JSON.stringify(response));
          return;
        }
        // 新增：处理活动报名/撤销接口（对应图片内容）
        if (req.url.startsWith('/api/actDetails/apply') && req.method === 'POST') {
          return sendJSON('success.json')
        }
        // 新增：处理我的报名列表接口（对应图片内容）
        if (req.url.startsWith('/api/myApplyList') && req.method === 'GET') {
          // 获取URL参数中的status筛选条件
          const url = new URL(req.url, 'http://localhost');
          const status = url.searchParams.get('status');
          
          const filePath = path.resolve(process.cwd(), `mock/myApplyList.json`);
          if (!fs.existsSync(filePath)) {
            res.statusCode = 404;
            res.setHeader('Content-Type', 'application/json');
            return res.end(JSON.stringify({ error: `Mock file not found: myApplyList.json` }));
          }
          
          const jsonData = JSON.parse(fs.readFileSync(filePath, 'utf-8'));
          let filteredList = jsonData.data.list;
          
          // 根据status参数进行筛选
          if (status && status !== '') {
            const statusNum = parseInt(status);
            filteredList = jsonData.data.list.filter(item => item.applyStatus === statusNum);
          }
          
          // 返回筛选后的数据
          const response = {
            error: 0,
            data: {
              current: 1,
              pageSize: 10,
              pageCount: 1,
              list: filteredList
            }
          };
          
          res.setHeader('Content-Type', 'application/json');
          res.end(JSON.stringify(response));
          return;
        }
        // 新增：处理活动来源列表接口（服务纪实）
        if (req.url.startsWith('/api/act/publisherList') && req.method === 'GET') {
          return sendJSON('publishers.json')
        }
        // 新增：处理服务时长列表接口（服务纪实）
        if (req.url.startsWith('/api/act/durationsList') && req.method === 'GET') {
          return sendJSON('durationList.json')
        }
        // 新增：处理服务纪实提交接口（服务纪实）
        if (req.url.startsWith('/api/act/uploadService') && req.method === 'POST') {
          return sendJSON('success.json')
        }
        // 新增：处理用户积分接口（我的服务）
        if (req.url.startsWith('/api/service/userScore') && req.method === 'GET') {
          return sendJSON('userScore.json')
        }
        // 新增：处理年份列表接口（我的服务）
        if (req.url.startsWith('/api/service/yearList') && req.method === 'GET') {
          return sendJSON('yearList.json')
        }
        // 新增：处理年度服务数据接口（我的服务）
        if (req.url.startsWith('/api/service/yearScore') && req.method === 'GET') {
          return sendJSON('yearScore.json')
        }
        // 新增：处理服务记录列表接口（我的服务）
        if (req.url.startsWith('/api/service/list') && req.method === 'GET') {
          return sendJSON('serviceList.json')
        }
        // 新增：处理服务详情接口（服务列表详情）
        if (req.url.startsWith('/api/service/details') && req.method === 'GET') {
          return sendJSON('recordDetails.json')
        }

        next()
      })
    },
  }
}

export default defineConfig({
  plugins: [vue(), mockPlugin()],
  resolve: {
    alias: {
      '@': path.resolve(__dirname, 'src') // 新增：配置@指向src目录
    }
  },
  // 可选：新增服务配置（避免端口占用、自动打开浏览器）
  server: {
    port: 5174, // 自定义端口（可修改）
    open: true, // 启动后自动打开浏览器
    host: '0.0.0.0' // 支持局域网访问（手机可测试）
  }
})