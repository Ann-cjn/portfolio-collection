// 导入Vue的创建函数和根组件
import { createApp } from 'vue'
import App from './App.vue'

// 1. 从vant中导入需要的组件（补充Toast、Tabbar等常用组件 + 补全之前漏的Toast）
import { 
  Button, List, Tag, Field, 
  CellGroup, Cell,
  Uploader, Popup, Picker, 
  Toast,
  Tabbar, TabbarItem,
  DatePicker,
  Icon
} from 'vant';
// 2. 导入vant的样式文件
import 'vant/lib/index.css';

// 引入路由配置
import router from './router'

// 引入axios（接口请求需要，之前漏了）
import axios from 'axios'

// 创建Vue应用实例
const app = createApp(App)

// 3. 注册Vant组件（补全注册）
app.use(Button)
   .use(List)
   .use(Tag)
   .use(Field)
   .use(CellGroup)
   .use(Cell)
   .use(Uploader)
   .use(Popup)
   .use(Picker)
   .use(Toast)
   .use(Tabbar)
   .use(TabbarItem)
   .use(DatePicker)
   .use(Icon)
   .use(router);

// 新增：全局挂载axios（接口请求更方便）
app.config.globalProperties.$axios = axios

// 挂载应用到页面
app.mount('#app')