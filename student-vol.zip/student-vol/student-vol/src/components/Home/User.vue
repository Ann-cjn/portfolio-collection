<template>
  <div class="user-header" @click="goToUserCenter">
    <div class="user-info">
      <img class="user-avatar" :src="userInfo?.avatar || ''" />
      <div class="user-details">
        <p class="user-name">{{ userInfo?.name || '未登录' }}</p>
      </div>
    </div>
    <div class="year-selector" v-if="showYearSelector">
      <van-button 
        round 
        hairline 
        size="mini" 
        icon="arrow-down" 
        color="#ff5d23" 
        @click.stop="showPicker = true"
      >
        {{ date?.text || '选择年份' }}
      </van-button>
    </div>
  </div>
  <van-popup v-model:show="showPicker" round position="bottom" @click.stop>
    <van-picker 
      :columns="dateList" 
      @cancel="cancel" 
      @confirm="confirm"
      :visible-item-count="3"
      :columns-field-names="{ text: 'text', value: 'value' }"
    />
  </van-popup>
</template>

<script>
import axios from 'axios';
export default {
  emits: ['updateYear'],
  props: {
    user: {
      type: Object,
      default: () => ({})
    },
    dateList: {
      type: Array,
      default: () => []
    },
    date: {
      type: Object,
      default: () => ({})
    },
    showYearSelector: {
      type: Boolean,
      default: true
    }
  },
  data() {
    return {
      showPicker: false,
      userData: {},
      userInfo: {}
    }
  },
  methods: {
    fetchUserData() {
      // 如果有传入的用户信息，使用传入的信息
      if (this.user && Object.keys(this.user).length > 0) {
        this.userInfo = this.user;
        return;
      }
      
      // 否则从API获取用户信息
      axios.get("/api/service/userScore")
        .then(res => {
          const { error, data = {} } = res.data;
          if (error === 0) this.userInfo = data;
        })
        .catch(err => {
          console.error('获取用户数据失败：', err);
          this.userInfo = { name: '未登录' };
        })
    },
    goToUserCenter() {
      this.$router.push('/userCenter');
    },
    cancel() { this.showPicker = false },
    confirm({ selectedOptions }) {
      this.showPicker = false;
      this.$emit('updateYear', selectedOptions[0]);
    }
  },
  watch: {
    // 监听props中user的变化，确保UI始终显示最新信息
    user: {
      handler(newVal) {
        if (newVal && Object.keys(newVal).length > 0) {
          this.userInfo = newVal;
        }
      },
      immediate: true, // 立即执行一次
      deep: true // 深度监听
    }
  },
  mounted() {
    this.fetchUserData();
  }
}
</script>

<style scoped>
.user-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 20px 16px;
  background-color: #e60012;
  border-radius: 0 0 16px 16px;
  cursor: pointer;
}
.user-info {
  display: flex;
  align-items: center;
}
.user-avatar {
  width: 48px;
  height: 48px;
  border-radius: 50%;
  border: 2px solid rgba(255, 255, 255, 0.3);
  margin-right: 12px;
}
.user-details {
  display: flex;
  flex-direction: column;
}
.user-name {
  font-size: 18px;
  font-weight: 600;
  color: #ffffff;
  margin: 0 0 4px 0;
}
.year-selector {
  flex-shrink: 0;
}
</style>
