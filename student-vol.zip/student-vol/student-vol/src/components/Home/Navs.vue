<template>
  <ul class="navs">
    <!-- 认事：点击时传递“认事”参数 -->
    <li @click="$emit('navClick', '认事')">
      <img src="../../../assets/p1.png" />
      <p>认事</p>
    </li>
    <!-- 爱心报表：传递“爱心报表”参数 -->
    <li @click="$emit('navClick', '爱心报表')">
      <img src="../../../assets/p2.png" />
      <p>爱心报表</p>
    </li>
    <!-- 服务纪实：移除“（待开发）”+ 传递“服务纪实”参数 -->
    <li @click="$emit('navClick', '服务纪实')">
      <img src="../../../assets/p3.png" />
      <p>服务纪实</p> <!-- 删掉“（待开发）” -->
    </li>
    <!-- 我的服务：移除“（待开发）”+ 传递“我的服务”参数 -->
    <li @click="$emit('navClick', '我的服务')">
      <img src="../../../assets/p5.png" />
      <p>我的服务</p> <!-- 删掉“（待开发）” -->
    </li>
  </ul>
</template>

<script>
export default {
  name: 'Navs'
}
</script>
<style scoped>
.navs {
padding: 0;
list-style: none;
margin: 30px 10px;
margin-bottom: 10px;
border-radius: 10px;
background: #fff;
}

.navs li {
width: 25%;
font-size: 14px;
height: 74px;
display: inline-flex;
flex-direction: column;
align-items: center;
justify-content: center;
text-align: center;
}

.navs li a {
color: #2c3e50;
text-decoration: none;
}

.navs img {
width: 26px;
height: 26px;
margin-bottom: 4px;
}
</style>