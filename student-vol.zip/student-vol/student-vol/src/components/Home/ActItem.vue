<template>
  <div class="actItem" @click="detailsClick(data.id)">
    <div class="actItem-pic">
      <!-- 活动图片 -->
      <img :src="data.actPic" />
      <!-- 根据状态决定样式 -->
      <span class="actItemtatus" :style="getTagStyle(data)">
        <!-- 根据状态展示标签 -->
        {{ getTagTxt(data) }}
      </span>
    </div>
    <div class="actItem-body">
      <p class="actItem-title">
        {{ data.title }} <!-- 标题 -->
      </p>
      <p> <!-- 开始时间至结束时间 -->
        {{ formatDate(data.startTime) }}
        至
        {{ formatDate(data.endTime) }}
      </p>
      <p class="actItem-tag"> <!-- 活动地点 -->
        {{ data.isYourSchool ? "本人所在学校活动" : data.palce }}
      </p>
    </div>
  </div>
</template>

<script>
import moment from "moment";
export default {
  props: ["data", "from"],
  methods: {
    // 根据状态设置标签样式
    getTagStyle(data) {
      // 如果是从报名状态页面来的，根据报名状态设置样式
      if (this.from === 'applyStatus') {
        const statusColorMap = {
          1: '#ff976a', // 审核中 - 橙色
          2: '#07c160', // 审核通过 - 绿色
          3: '#ee0a24'  // 审核拒绝 - 红色
        };
        return { backgroundColor: statusColorMap[data.applyStatus] || '#969799' };
      }
      // 否则根据活动状态设置样式
      return { backgroundColor: data.canApply ? "#07c160" : "#ff976a" };
    },
    // 格式化日期
    formatDate(value) {
      return value ? moment(value).format("YYYY-MM-DD hh:mm") : "";
    },
    // 触发详情页跳转事件
    detailsClick(id) {
      this.$emit("goDetails", id);
    },
    // 根据状态展示标签文字
    getTagTxt(data) {
      // 如果是从报名状态页面来的，显示报名状态
      if (this.from === 'applyStatus') {
        const statusMap = {
          1: '审核中',
          2: '审核通过', 
          3: '审核拒绝'
        };
        return statusMap[data.applyStatus] || '未知状态';
      }
      // 否则显示活动状态
      return data.canApply ? "进行中" : "已结束";
    },
  }
};
</script>
<style scoped>
.actItem {
    padding: 10px 0;
    display: flex;
    justify-content: flex-start;
}

.actItem-pic {
    width: 108px;
    height: 69px;
    position: relative;
}

.actItemtatus {
    font-size: 12px;
    color: #fff;
    padding: 0 5px;
    position: absolute;
    left: 0;
    bottom: 0;
    background-color: #ff976a;
    border-top-right-radius: 4px;
}

.active {
    background-color: #07C160;
}

.actItem img {
    width: 100%;
    height: 100%;
    margin-right: 10px;
}

.actItem-body {
    font-size: 12px;
    text-align: left;
    color: #666;
}

.actItem-title {
    font-size: 14px;
    color: black;
    margin-bottom: 6px;
}

.actItem-tag {
    display: inline-block;
    background: #ffe9d5;
    border-radius: 10px;
    font-size: 12px;
    color: #ff7d23;
    line-height: 20px;
    padding: 0 5px;
    margin-top: 6px;
}
</style>