<template>
  <div class="overview-container">
    <ul class="overview">
      <li>
        <p class="num">
          <span class="highColor">{{ data.times || 0 }}</span>次
        </p>
        <span class="label">服务次数</span>
      </li>
      <li>
        <p class="num">
          <span class="highColor">{{ data.duration || 0 }}</span>小时
        </p>
        <span class="label">服务时长</span>
      </li>
      <li>
        <p class="num">
          <span class="highColor">{{ data.score || 0 }}</span>分
        </p>
        <span class="label">服务积分</span>
      </li>
    </ul>
  </div>
</template>

<script>
import axios from 'axios';
export default {
  props: ["year", "data"],
  methods: {
    fetchYearScore() {
      if (!this.year) return;
      const that = this;
      axios.get('/api/service/yearScore', {
        params: { year: this.year }
      })
        .then(function (response) {
          const { error, data = {} } = response.data;
          if (error === 0) {
            that.$emit('updateData', data);
          }
        })
    }
  },
  watch: {
    year() {
      this.fetchYearScore();
    }
  },
  mounted() {
    if (this.year) {
      this.fetchYearScore();
    }
  }
}
</script>

<style scoped>
.overview-container {
  background-color: #ffffff;
  border-radius: 12px;
  padding: 16px;
  margin: 12px 16px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.04);
}
.overview {
  display: flex;
  justify-content: space-around;
  list-style: none;
  margin: 0;
  padding: 0;
}
.overview li {
  display: flex;
  flex-direction: column;
  align-items: center;
  flex: 1;
}
.num {
  font-size: 14px;
  color: #606266;
  margin: 0 0 8px 0;
}
.highColor {
  font-size: 24px;
  font-weight: 700;
  color: #ff5d23;
  margin-right: 2px;
}
.label {
  font-size: 13px;
  color: #909399;
}
</style>
