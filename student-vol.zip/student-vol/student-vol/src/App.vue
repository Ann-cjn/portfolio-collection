<template>
  <!-- 路由出口：所有路由页面（如HomeView、LoveActs）都会在这里渲染 -->
  <router-view />
</template>

<script>
import axios from 'axios';

export default {
  mounted() {
    // 1. 发送GET请求（对应PPT中的/api/studentList）
    axios.get('/api/studentList')
      .then(function (res) {
        console.log(res.data.data); // 打印Mock数据中的学生列表
      });

    // 2. 原有的/user GET请求
    axios.get("/user")
      .then(function (res) {
        console.log(res);
      });

    // 3. 原有的/addUser POST请求
    axios.post('/addUser', {name:'张三', age:18})
      .then(function (res) {
        console.log(res.data);
      });
  }
}
</script>

<style scoped>
/* 样式可根据需求补充 */
</style>