import { createRouter, createWebHistory } from 'vue-router'

const routes = [
  {
    path: '/',
    name: 'home',
    component: () => import('../views/HomeView.vue') // 路由懒加载
  },
  // 个人信息维护页面路由
  {
    path: '/userCenter',
    name: 'userCenter',
    component: () => import('../views/UserCenter.vue')
  },
  // 积分排名页面路由
  {
    path: '/loveReport',
    name: 'loveReport',
    component: () => import('../views/LoveReport.vue')
  },
  // 活动列表页面路由
  {
    path: '/loveActs',
    name: 'loveActs',
    component: () => import('../views/LoveActs.vue')
  },
  // 新增：活动详情页面路由
  {
    path: '/actDetails',
    name: 'actDetails',
    component: () => import('../views/ActDetails.vue')
  },
  // 新增：我的报名页面路由
  {
    path: '/myApply',
    name: 'myApply',
    component: () => import('../views/MyApply.vue')
  },
  // 新增：服务纪实页面路由
  {
    path: '/uploadService',
    name: 'uploadService',
    component: () => import('../views/UploadService.vue')
  },
  // 新增：我的服务页面路由
  {
    path: '/serviceRecords',
    name: 'serviceRecords',
    component: () => import('../views/ServiceRecords.vue')
  },
  // 新增：服务列表详情页面路由
  {
    path: '/serviceDetail',
    name: 'serviceDetail',
    component: () => import('../views/ServiceDetail.vue')
  }
]

const router = createRouter({
  history: createWebHistory(),
  routes
})

export default router