<template>
  <div class="service-records-container">
    <!-- 1. 用户信息与年份选择 -->
    <div class="header">
      <User 
        @updateYear="updateYear" 
        :date="year" 
        :dateList="dateList"
        :user="userInfo"
      />
    </div>

    <!-- 2. 年度服务统计 -->
    <div class="overview" v-if="overviewData">
      <Overview :year="year?.value" :data="overviewData"></Overview>
    </div>

    <!-- 3. 服务记录列表 -->
    <div class="records-list">
      <van-list 
        v-model:loading="loading" 
        :finished="finished" 
        finished-text="没有更多了"
        @load="onLoad"
      >
        <RecordItem 
          v-for="item in dataList" 
          :key="item?.id || item?.recordId" 
          :data="item"
          @goDetails="goDetails"
        />

        <div class="empty" v-if="!loading && dataList.length === 0 && year?.value">
          暂无服务记录
        </div>
      </van-list>
    </div>
  </div>
</template>

<script>
import User from '../components/Home/User.vue';
import Overview from '../components/Home/Overview.vue';
import RecordItem from '../components/Home/RecordItem.vue';
import { showFailToast } from 'vant';
import axios from 'axios';

export default {
  name: 'ServiceRecords',
  components: { User, Overview, RecordItem },
  data() {
    return {
      dataList: [],
      loading: false,
      finished: false,
      currentPage: 1,
      userInfo: { avatar: "", name: "" },
      year: { text: '2024年', value: 2024 },
      dateList: [
        { text: '2024年', value: 2024 },
        { text: '2023年', value: 2023 },
        { text: '2022年', value: 2022 }
      ],
      overviewData: {
        times: 3,
        duration: 14,
        score: 14
      }
    };
  },
  methods: {
    updateYear(yearValue) {
      if (!yearValue) return;
      this.year = yearValue;
      this.currentPage = 1;
      this.dataList = [];
      this.finished = false;
      this.fetchServiceRecords(1);
    },
    fetchUserInfo() {
      axios.get("/api/userInfo")
        .then(response => {
          const { error, data = {} } = response.data;
          if (error === 0) {
            this.userInfo = {
              avatar: data.avatar,
              name: data.name,
              code: data.code || "212306157",
              school: data.school || "福州大学至诚学院"
            };
          }
        })
        .catch(error => {
          console.error('获取用户信息失败：', error);
        });
    },
    fetchServiceRecords(currentPage = 1) {
      this.loading = true;
      
      // 调用API获取服务记录列表
      axios.get('/api/service/list', {
        params: {
          page: currentPage,
          pageSize: 10,
          year: this.year?.value
        }
      })
      .then(response => {
        const { error, data } = response.data;
        if (error === 0) {
          const newList = data?.list || [];
          if (currentPage === 1) {
            this.dataList = newList;
          } else {
            this.dataList = [...this.dataList, ...newList];
          }
          this.finished = !data?.hasMore;
          this.currentPage = currentPage;
        } else {
          showFailToast('获取服务记录失败');
          this.finished = true;
        }
      })
      .catch(err => {
        console.error('获取服务记录失败：', err);
        showFailToast('网络异常，请稍后重试');
        this.finished = true;
      })
      .finally(() => {
        this.loading = false;
      });
    },
    onLoad() {
      if (this.finished || this.loading) return;
      this.fetchServiceRecords(this.currentPage + 1);
    },
    goDetails(id) {
      if (!id) return showFailToast('记录ID不存在');
      this.$router.push({ 
        path: '/serviceDetail', 
        query: { id }
      });
    }
  },
  mounted() {
    console.log('ServiceRecords 组件已挂载');
    // 获取用户信息
    this.fetchUserInfo();
    // 初始化加载数据
    this.fetchServiceRecords(1);
  }
};
</script>

<style scoped>
.header {
  padding: 10px 10px 44px 10px;
  background-color: #c82519;
}

.overview {
  padding: 14px;
  margin-top: -24px;
}
</style>