<template>
  <div class="container">
    <!-- 标题 -->
    <h1 class="title">{{ actDetails.title || '加载中...' }}</h1>
    <!-- 状态标签 -->
    <div class="status-group">
      <span class="status-tag" :class="actDetails.canApply ? 'status-active' : 'status-ended'">
        {{ actDetails.canApply ? '进行中' : '已结束' }}
      </span>
      <span class="status-tag status-audit">{{ getAuditStatusText(actDetails.applyStatus) }}</span>
    </div>
    <!-- 分隔线 -->
    <div class="divider"></div>

    <!-- 信息列表 -->
    <div class="info-list">
      <div class="info-item">
        <span class="label">活动时间</span>
        <span class="value">{{ formatTime(actDetails.startTime) }} - {{ formatTime(actDetails.endTime) }}</span>
      </div>
      <div class="info-item">
        <span class="label">活动地点</span>
        <span class="value">{{ actDetails.palce || '-' }}</span>
      </div>
      <div class="info-item">
        <span class="label">活动简介</span>
        <span class="value">{{ actDetails.content || '-' }}</span>
      </div>
      <div class="info-item">
        <span class="label">活动来源</span>
        <span class="value">{{ actDetails.publisher || '-' }}</span>
      </div>
      <div class="info-item">
        <span class="label">服务时长</span>
        <span class="value">{{ actDetails.hour || 0 }}小时</span>
      </div>
      <div class="info-item">
        <span class="label">招募人数</span>
        <span class="value">{{ actDetails.total || 0 }}人</span>
      </div>
    </div>

    <!-- 空白占位块 -->
    <div class="empty-block"></div>

    <!-- 操作按钮：添加禁用状态 -->
    <button 
      class="action-btn" 
      @click="handleCancelApply"
      :disabled="isBtnDisabled"
    >
      {{ getActionBtnText(actDetails.applyStatus) }}
    </button>
  </div>
</template>

<script>
import axios from 'axios';
import moment from 'moment';

export default {
  data() {
    return {
      actDetails: {
        id: 0,
        title: '',
        content: '',
        startTime: 0,
        endTime: 0,
        publisher: '',
        hour: 0,
        palce: '',
        isYourSchool: false,
        canApply: true,
        total: 0,
        applyStatus: 1 // 1: 审核中, 2: 审核通过, 3: 审核拒绝
      },
      isBtnDisabled: false // 按钮禁用状态
    }
  },
  methods: {
    // 获取活动详情数据
    fetchActDetails() {
      const actId = this.$route.query.id;
      const status = this.$route.query.status; // 获取状态参数
      if (!actId) {
        console.error('缺少活动ID参数');
        return;
      }
      
      console.log('请求详情数据:', { actId, status }); // 添加调试日志
      console.log('请求参数类型:', { actIdType: typeof actId, statusType: typeof status }); // 添加调试日志
      
      axios.get('/api/actDetails', { params: { id: actId, status: status } })
        .then(response => {
          console.log('API响应:', response.data); // 添加调试日志
          const { error, data = {} } = response.data;
          if (error === 0) {
            this.actDetails = data.details || this.actDetails;
            console.log('更新后的活动详情:', this.actDetails); // 添加调试日志
            console.log('当前显示的状态文本:', this.getAuditStatusText(this.actDetails.applyStatus)); // 添加调试日志
          } else {
            console.error('获取活动详情失败');
          }
        })
        .catch(err => {
          console.error('获取活动详情失败：', err);
        });
    },
    
    // 格式化时间
    formatTime(timestamp) {
      if (!timestamp) return '-';
      return moment(timestamp).format('YYYY-MM-DD HH:mm');
    },
    
    // 获取审核状态文本
    getAuditStatusText(status) {
      const statusMap = {
        1: '审核中',
        2: '审核通过', 
        3: '审核拒绝',
        4: '已撤销'
      };
      return statusMap[status] || '未知状态';
    },
    
    // 获取操作按钮文本
    getActionBtnText(status) {
      // 根据审核状态返回不同的按钮文本
      if (status === 1) return '撤销申请'; // 审核中
      if (status === 2) return '已完成'; // 审核通过
      if (status === 3) return '重新申请'; // 审核拒绝
      if (status === 4) return '已撤销'; // 已撤销
      return '操作';
    },
    
    // 撤销申请的逻辑
    handleCancelApply() {
      // 只有在审核中才能撤销申请
      if (this.actDetails.applyStatus !== 1) {
        alert('只有审核中的申请才能撤销');
        return;
      }
      
      // 1. 禁用按钮，防止重复点击
      this.isBtnDisabled = true;

      // 2. 调用接口撤销申请
      const actId = this.$route.query.id;
      axios.post('/api/actDetails/apply', {
        isApply: false, // 标识为"撤销申请"
        id: actId
      })
      .then(response => {
        const { error, msg } = response.data;
        if (error === 0) {
          // 撤销成功：更新状态
          this.actDetails.applyStatus = 4; // 设置为已撤销
          alert('撤销申请成功');
        } else {
          // 撤销失败：提示错误
          alert(msg || '撤销申请失败');
          this.isBtnDisabled = false; // 恢复按钮
        }
      })
      .catch(err => {
        console.error('撤销申请失败：', err);
        alert('网络异常，请稍后重试');
        this.isBtnDisabled = false; // 恢复按钮
      });
    }
  },
  created() {
    // 组件创建时获取活动详情
    this.fetchActDetails();
  }
}
</script>

<style scoped>
/* 页面容器 */
.container {
  max-width: 600px;
  margin: 0 auto;
  padding: 20px 15px;
  font-family: "PingFang SC", "Microsoft YaHei", sans-serif;
  color: #333;
}

/* 标题样式 */
.title {
  font-size: 18px;
  font-weight: 600;
  margin: 0 0 8px 0;
}

/* 状态标签 */
.status-group {
  margin-bottom: 10px;
}
.status-tag {
  display: inline-block;
  font-size: 12px;
  padding: 2px 8px;
  border-radius: 12px;
  color: #fff;
  margin-right: 6px;
}
.status-active {
  background-color: #07C160; /* 进行中-绿色 */
}
.status-ended {
  background-color: #ff976a; /* 已结束-橙色 */
}
.status-audit {
  background-color: #1989fa; /* 审核中/已撤销-蓝色 */
}

/* 分隔线 */
.divider {
  height: 1px;
  background-color: #eee;
  margin-bottom: 15px;
}

/* 信息列表 */
.info-list {
  margin-bottom: 15px;
}
.info-item {
  display: flex;
  margin-bottom: 10px;
  align-items: flex-start;
}
.label {
  width: 80px;
  font-size: 14px;
  color: #999;
  padding-top: 2px;
}
.value {
  flex: 1;
  font-size: 14px;
  line-height: 1.5;
}

/* 空白占位块 */
.empty-block {
  height: 150px;
  background-color: #f6f6f6;
  margin-bottom: 15px;
  border-radius: 4px;
}

/* 操作按钮 */
.action-btn {
  width: 100%;
  height: 44px;
  background-color: #ff5d23;
  color: #fff;
  border: none;
  font-size: 16px;
  font-weight: 500;
  cursor: pointer;
}
.action-btn:disabled {
  background-color: #ccc;
  cursor: not-allowed;
}
</style>