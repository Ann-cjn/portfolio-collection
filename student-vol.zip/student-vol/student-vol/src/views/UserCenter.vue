<template> 
   <div class="container"> 
     <div class="inner"> 
       <h1>个人信息</h1> 
       <ul> 
         <li> 
           <p class="label"><span>*</span>姓名</p> 
           <span class="txt">{{ name }}</span> 
         </li> 
         <li> 
           <p class="label"><span>*</span>编号</p> 
           <span class="txt">{{ code }}</span> 
         </li> 
         <li> 
           <p class="label"><span>*</span>性别</p> 
           <input type="radio" value="0" v-model="gender" />男 
           <input type="radio" value="1" v-model="gender" />女 
         </li> 
         <li> 
           <p class="label"><span>*</span>手机号</p> 
           <input placeholder="请输入手机号" v-model.trim="phoneNum" /> 
         </li> 
         <li> 
           <p class="label"><span>*</span>学校</p> 
           <input placeholder="请输入学校名称" v-model.trim="school" /> 
         </li> 
         <li> 
           <p class="label"><span>*</span>专业</p> 
           <input placeholder="请输入专业名称" v-model.trim="profession" /> 
         </li> 
         <li> 
           <p class="label"><span>*</span>人员属性</p> 
           <div class="userTypeList"> 
             <span :class="{active: userType === 0}" @click="changeUserType(0)">群众</span> 
             <span :class="{active: userType === 1}" @click="changeUserType(1)">团员</span> 
             <span :class="{active: userType === 2}" @click="changeUserType(2)">党员</span> 
           </div> 
         </li> 
       </ul> 
       <button class="subBtn" @click="submitClick">提交</button> 
     </div> 
   </div> 
 </template> 
 
 <script> 
 import axios from 'axios'; 
 import { showToast, showSuccessToast, showFailToast } from 'vant'; 
 
 export default { 
   data() { 
     return { 
       name: "曹佳妮", 
       code: "212306157", 
       gender: "1", 
       phoneNum: "123456789", 
       school: "福州大学至诚学院", 
       profession: "计算机科学与技术", 
       userType: 0 
     }; 
   }, 
   methods: { 
     changeUserType(value) { 
       this.userType = value; 
     }, 
     // 修正：接口路径与mock配置一致（原接口为/api/userInfo，非/api/userInfo/get） 
     fetchUserInfo() { 
       const that = this; 
       axios.get('/api/userInfo') 
         .then(function (response) { 
           const { error, data = {} } = response.data; 
           if (error === 0) { 
             that.name = data.name || ""; 
             that.code = data.code || ""; 
             that.gender = String(data.gender) || "0"; 
             that.phoneNum = data.phoneNum || ""; 
             that.school = data.school || ""; 
             that.profession = data.profession || ""; 
             that.userType = data.userType || 0; 
           } else { 
             showFailToast("获取信息失败"); 
           } 
         }) 
         .catch(err => { 
           console.error('获取用户信息失败：', err); 
           showFailToast("网络异常"); 
         }); 
     }, 
     check() { 
       const phoneNum = this.phoneNum.trim(); 
       const school = this.school.trim(); 
       const profession = this.profession.trim(); 
 
       if (!phoneNum) { 
         showToast("手机号不可为空"); 
         return null; 
       } 
       if (!school) { 
         showToast("学校不可为空"); 
         return null; 
       } 
       if (!profession) { 
         showToast("专业不可为空"); 
         return null; 
       } 
 
       return { 
         name: this.name, 
         code: this.code, 
         gender: Number(this.gender), 
         phoneNum, 
         school, 
         profession, 
         userType: this.userType 
       }; 
     }, 
     submitClick() { 
       const payload = this.check(); 
       if (!payload) return; 
 
       axios.post('/api/userInfo/submit', payload) 
         .then(function (response) { 
           const { error, msg } = response.data; 
           if (error === 0) { 
             showSuccessToast("操作成功"); 
           } else { 
             showFailToast(msg || '提交失败，请稍后重试'); 
           } 
         }) 
         .catch(err => { 
           console.error('提交表单失败：', err); 
           showFailToast("网络异常"); 
         }); 
     } 
   }, 
   mounted() { 
     this.fetchUserInfo(); 
   } 
 }; 
 </script> 
 
 <style scoped> 
 .container { 
   background-color: #f6f6f6; 
   padding: 20px 10px; 
   height: 100%; 
 } 
 
 .inner { 
   background-color: #fff; 
   border-radius: 16px; 
   padding: 20px; 
 } 
 
 h1 { 
   font-size: 16px; 
   font-weight: bold; 
   margin: 0; 
   padding-bottom: 10px; 
   color: #000; 
 } 
 
 ul { 
   margin: 0; 
   padding: 0; 
   list-style: none; 
   font-size: 14px; 
 } 
 
 ul li { 
   padding: 14px 0; 
   border-bottom: 1px solid #f3f3f3; 
   display: flex; 
   align-items: center; 
 } 
 
 .label { 
   display: inline-block; 
   width: 80px; 
 } 
 
 .label span { 
   color: red; 
   margin-right: 2px; 
 } 
 
 input { 
   border: none; 
   outline: none; 
 } 
 
 .userTypeList { 
   display: inline-flex; 
 } 
 
 .userTypeList span { 
   display: inline-block; 
   padding: 3px 12px; 
   background-color: #f6f6f6; 
   color: #333; 
   border-radius: 10px; 
   font-size: 12px; 
   margin-right: 4px; 
 } 
 
 .subBtn { 
   width: 100%; 
   font-size: 14px; 
   color: #fff; 
   background-color: #ff5d23; 
   border: none; 
   line-height: 32px; 
   border-radius: 16px; 
   margin-top: 40px; 
   cursor: pointer; 
 } 
 
 .userTypeList .active { 
   background: #ffe9d5; 
   color: #ff7d23; 
 } 
 
 .txt { 
   color: #999; 
 } 
 </style>