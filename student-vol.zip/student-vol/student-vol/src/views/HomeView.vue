<template> 
    <div class="home"> 
      <!-- 头部：保持你的结构，补充红色背景（匹配示例） -->
      <div class="header" style="background-color: #e62129;"> 
        <h1>大学生志愿者活动</h1> 
        <div class="user-wrapper"> 
          <User :user="userInfo" :showYearSelector="false" /> 
        </div> 
      </div> 
  
      <!-- 功能导航：保持你的结构 -->
      <div class="navs"> 
        <div class="nav-item" @click="$router.push('/loveActs')"> 
          <img src="../assets/p1.png" /> 
          <p>认事</p> 
        </div> 
        <div class="nav-item" @click="$router.push('/loveReport')"> 
          <img src="../assets/p2.png" /> 
          <p>爱心报表</p> 
        </div> 
        <div class="nav-item" @click="$router.push('/uploadService')"> 
          <img src="../assets/p3.png" /> 
          <p>服务纪实</p> 
        </div> 
        <div class="nav-item" @click="$router.push('/serviceRecords')"> 
          <img src="../assets/p5.png" /> 
          <p>我的服务</p> 
        </div> 
      </div>
      
      <!-- 志愿活动列表：保持你的结构，补充活动状态标签（匹配示例） -->
      <div class="list"> 
        <div class="list-header"> 
          <span>志愿活动</span> 
          <div class="list-more" @click="goMoreActs"> 
            查看更多 
            <img src="/src/assets/rArrow.png" /> 
          </div> 
        </div> 
        <div class="actList"> 
          <ActItem 
            v-for="item in list" 
            :key="item.id" 
            :data="item" 
            @goDetails="goDetails" 
          /> 
        </div> 
      </div> 
    </div> 
  </template> 
  
  <script> 
  import axios from 'axios'; 
  import User from '../components/Home/User.vue'; 
  import ActItem from '../components/Home/ActItem.vue'; 
  
  export default { 
    components: { 
      User, 
      ActItem 
    }, 
    data() { 
      return { 
        userInfo: { avatar: "", name: "" }, 
        list: [] 
      }; 
    }, 
    methods: { 
      // 保持你的获取用户信息逻辑
      fetchUserInfo() { 
        const that = this; 
        axios.get("/api/userInfo") 
          .then(function (response) { 
            const { error, data = {} } = response.data; 
            if (error === 0) { 
              // 确保从API获取的数据正确设置到userInfo中
              that.userInfo = { 
                avatar: data.avatar, 
                name: data.name,
                score: data.score || "0",
                code: data.code || "212306157",
                school: data.school || "福州大学至诚学院"
              }; 
            } else {
              // 如果API返回错误，设置默认值
              that.userInfo = {
                avatar: "",
                name: "曹佳妮", // 设置默认值
                score: "0",
                code: "212306157",
                school: "福州大学至诚学院"
              };
            } 
          })
          .catch(function (error) {
            // 如果请求失败，设置默认值
            console.error('获取用户信息失败：', error);
            that.userInfo = {
              avatar: "",
              name: "曹佳妮", // 设置默认值
              score: "0",
              code: "212306157",
              school: "福州大学至诚学院"
            };
          }); 
      }, 
      // 保持你的获取活动列表逻辑，补充状态字段（匹配示例）
      fetchActList() { 
        const that = this; 
        axios.get("/api/actList") 
          .then(function (response) { 
            const { error, data = {} } = response.data; 
            if (error === 0) { 
              // 给活动列表补充status字段（匹配示例的“进行中/已结束”）
              that.list = data.list.map(item => ({
                ...item,
                status: item.canApply ? "进行中" : "已结束"
              })); 
            } 
          }); 
      }, 
      goDetails(id) { 
        this.$router.push('/actDetails?id=' + id); 
      }, 
      goMoreActs() { 
        this.$router.push("/loveActs"); 
      } 
    }, 
    mounted() { 
      this.fetchUserInfo(); 
      this.fetchActList(); 
    } 
  }; 
  </script> 
  
  <style scoped> 
  /* 保持你原有样式，仅补充头部文字颜色（匹配红色背景） */
  .header { 
      height: 80px; 
      padding-top: 20px; 
      position: relative; 
  } 
  
  .header h1 { 
      margin: 0; 
      font-size: 20px; 
      color: #fff; /* 红色背景下文字改为白色 */
      letter-spacing: 2px; 
      font-weight: normal; 
      text-align: center; 
  } 
  
  .user-wrapper { 
    position: absolute; 
    bottom: 10px; 
    left: 20px; 
    width: calc(100% - 40px); 
  } 
  
  .list { 
      padding: 10px 20px; 
      background-color: #fff; 
  } 
  
  .list-header { 
      display: flex; 
      justify-content: space-between; 
      align-items: center; 
      font-size: 14px; 
  } 
  
  .list-more { 
      display: flex; 
      align-items: center; 
      font-size: 12px; 
      color: #999; 
  } 
  
  .list-more img { 
      width: 16px; 
      height: 16px; 
  } 
  
  .navs { 
    display: flex; 
    justify-content: space-around; 
    padding: 10px 0; 
    background: #fff; 
    margin-bottom: 10px; 
  } 
  .nav-item { 
    display: flex; 
    flex-direction: column; 
    align-items: center; 
    cursor: pointer; 
  } 
  .nav-item img { 
    width: 40px; 
    height: 40px; 
    margin-bottom: 5px; 
  } 
  .nav-item p { 
    font-size: 12px; 
    margin: 0; 
  } 
  
  .actList { 
    margin-top: 10px; 
  } 
  </style> 