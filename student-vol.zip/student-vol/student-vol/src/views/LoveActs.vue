<template>
  <div class="container">
    <!-- 搜索区域（固定在顶部） -->
    <div class="searchBox">
      <div class="search">
        <span class="search-icon"></span>
        <input placeholder="请输入地点、活动名称等关键字" v-model="keyword" />
      </div>
    </div>

    <!-- 活动列表区域（Vant下拉加载） -->
    <div class="body">
      <van-list 
        v-model:loading="loading" 
        :finished="finished" 
        finished-text="没有更多了" 
        @load="onLoad"
      >
        <ActItem 
          v-for="item in actList" 
          :key="item.id" 
          :data="item"
          @goDetails="goDetails"
        ></ActItem>
      </van-list>
    </div>

    <!-- 底部“我的报名”按钮 -->
    <button class="fBtn" @click="goMyApply">我的报名</button>
  </div>
</template>

<script>
import axios from 'axios';
// 引入活动项组件（路径匹配你的目录结构）
import ActItem from '../components/Home/ActItem.vue';
import { List } from 'vant';

export default {
  components: {
    ActItem,
    vanList: List // 注册为van-list，匹配模板标签
  },
  data() {
    return {
      actList: [],          // 展示用的筛选后列表
      originalActList: [],  // 后端返回的全量原始列表（补充地点后）
      loading: false,       // 下拉加载状态
      finished: false,      // 是否加载完所有数据
      currentPage: 1,       // 当前请求页码
      keyword: ""           // 搜索关键字
    };
  },
  methods: {
    /**
     * 获取活动列表数据（后端返回全量数据，前端补充地点后筛选）
     * @param {number} currentPage - 请求页码
     */
    fetchActList(currentPage = 1) {
      const payload = {
        currentPage,
        pageSize: 10,
        keyword: "" // 清空关键词，让后端返回全量数据
      };
      this.loading = true;
      axios.get('/api/actList', { params: payload })
        .then(response => {
          const { error, data = {} } = response.data;
          if (error === 0) {
            const { current, list, pageCount } = data;
            
            // 核心修改：前端临时补充place字段（模拟后端数据）
            const listWithPlace = list.map((item, index) => {
              // 为每个活动分配不同的地点，覆盖空的place字段
              const mockPlaces = [
                "本人所在学校活动", 
                "凤凰池站", 
                "闽江公园", 
                "三坊七巷", 
                "上下杭"
              ];
              return { 
                ...item, 
                place: mockPlaces[index % mockPlaces.length] // 循环分配地点
              };
            });

            // 存储补充地点后的全量数据
            if (current === 1) {
              this.originalActList = listWithPlace;
            } else {
              this.originalActList = [...this.originalActList, ...listWithPlace];
            }
            this.currentPage = current;
            this.finished = current === pageCount;
            
            // 新增日志：打印补充后的所有地点
            console.log("补充后的所有活动地点：", this.originalActList.map(item => item.place));
            // 触发前端筛选
            this.filterActList();
          }
        })
        .catch(err => {
          console.error('获取活动列表失败：', err);
          this.finished = true; // 出错时标记加载完成
        })
        .finally(() => {
          this.loading = false;
        });
    },

    /**
     * 前端本地筛选活动列表（匹配title/place字段）
     */
    filterActList() {
      const keyword = this.keyword.trim().toLowerCase();
      // 新增日志：打印当前筛选关键词
      console.log("当前筛选关键词：", keyword);
      
      // 无关键词时展示全量数据
      if (!keyword) {
        this.actList = [...this.originalActList];
        return;
      }
      
      // 筛选包含关键词的活动（匹配title或place）
      this.actList = this.originalActList.filter(item => {
        const actTitle = item.title?.toLowerCase() || "";
        const actPlace = item.place?.toLowerCase() || "";
        
        // 新增日志：打印每个活动的名称和地点（小写）
        console.log("活动名称：", actTitle, "活动地点：", actPlace);
        
        return actTitle.includes(keyword) || actPlace.includes(keyword);
      });
      
      // 新增日志：打印筛选结果数量
      console.log("筛选后活动数量：", this.actList.length);
    },

    /**
     * 下拉加载触发（加载下一页）
     */
    onLoad() {
      this.fetchActList(this.currentPage + 1);
    },

    /**
     * 跳转“我的报名”页面
     */
    goMyApply() {
      this.$router.push("/myApply");
    },

    /**
     * 跳转活动详情页
     */
    goDetails(id) {
      this.$router.push(`/actDetails?id=${id}`);
    }
  },
  watch: {
    /**
     * 关键词变化时触发前端筛选
     */
    keyword() {
      this.filterActList();
    }
  },
  mounted() {
    // 页面初始化时请求第一页数据
    this.fetchActList(1);
  }
};
</script>

<style scoped>
.container {
    background-color: #fff;
    padding: 70px 10px 50px; /* 适配顶部搜索栏和底部按钮 */
}

/* 顶部搜索栏（固定定位） */
.searchBox {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    padding: 20px 10px;
    background-color: #fff;
    z-index: 2; /* 确保在内容上方 */
}
.search {
    background-color: #f6f6f6;
    height: 30px;
    border-radius: 18px;
    display: flex;
    align-items: center;
    padding: 0 10px;
}
/* 搜索图标（适配src/assets路径） */
.search-icon {
    display: inline-block;
    width: 16px;
    height: 16px;
    background-image: url(/src/assets/search.png); /* Vite绝对路径 */
    background-size: 100% 100%;
    margin-right: 8px;
}
.search input {
    flex: 1;
    border: none;
    outline: none;
    background-color: transparent;
    font-size: 14px;
}

/* 活动列表区域 */
.body {
    min-height: calc(100vh - 120px); /* 适配顶部和底部高度 */
}

/* 底部“我的报名”按钮 */
.fBtn {
    position: fixed;
    bottom: 0;
    left: 0;
    width: 100%;
    line-height: 40px;
    font-size: 18px;
    border: none;
    background-color: #ff5d23;
    color: #fff;
    cursor: pointer;
}
</style>