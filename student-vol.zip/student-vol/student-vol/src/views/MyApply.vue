<template>
  <div class="container">
    <ul class="tabList">
      <li @click="tabClick(0)">
        <span :class="curTab === 0 ? 'active' : ''">全部</span>
      </li>
      <li @click="tabClick(1)">
        <span :class="curTab === 1 ? 'active' : ''">审核中</span>
      </li>
      <li @click="tabClick(2)">
        <span :class="curTab === 2 ? 'active' : ''">审核通过</span>
      </li>
      <li @click="tabClick(3)">
        <span :class="curTab === 3 ? 'active' : ''">审核拒绝</span>
      </li>
    </ul>
    <div class="list">
      <van-list 
        v-model:loading="loading" 
        :finished="finished" 
        finished-text="没有更多了"
        @load="onLoad"
      >
        <ActItem 
          v-for="item in actList" 
          :key="item.id" 
          :data="item" 
          @goDetails="goDetails" 
          from="applyStatus"
        ></ActItem>
      </van-list>
    </div>
  </div>
</template>

<script>
import axios from 'axios';
import ActItem from '../components/Home/ActItem.vue';

export default {
  components: {
    ActItem
  },
  data() {
    return {
      curTab: 0, // 0: 全部、1：审核中、2：审核通过、3：审核拒绝
      actList: [],
      loading: false,
      finished: false,
      curentPage: 1
    };
  },
  methods: {
    tabClick(value) {
      this.curTab = value;
      this.currentPage = 1;
      this.fetchApplyList(1);
    },
    fetchApplyList(currentPage = 1) {
      const that = this;
      const payload = {
        currentPage,
        pageSize: 10,
        type: this.curTab
      };
      // 请求数据时，则处于加载状态
      this.loading = true;
      axios.get('/api/myApplyList', { params: payload })
        .then(function (response) {
          const { error, data = {} } = response.data;
          if (error === 0) {
            const currentPage = data.current;
            const list = data.list;
            // 当前为第一页，则覆盖已有的活动列表
            if (currentPage === 1) {
              that.actList = list;
            } else {
              // 在已有的活动列表后添加新的数据
              that.actList.push(...list);
            }
            that.currentPage = currentPage;
            // 当前数据的页数等于总页数，则说明没有更多数据了
            that.finished = data.pageCount === currentPage;
          }
        })
        .finally(function () {
          // 请求结束后，处于非加载状态
          that.loading = false;
        });
    },
    onLoad() {
      this.fetchApplyList(this.currentPage + 1);
    },
    goDetails(id) {
      this.$router.push('/actDetails?id=' + id);
    }
  },
  mounted() {
    this.fetchApplyList(1);
  }
};
</script>

<style scoped>
.container {
  height: 100%;
}

.tabList {
  list-style: none;
  margin: 0;
  padding: 0;
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  display: flex;
  justify-content: center;
  align-items: center;
  background-color: #fff;
  z-index: 100;
}

.tabList li {
  width: 25%;
  text-align: center;
  padding: 10px 0;
  font-size: 14px;
}

span.active {
  border-bottom: 2px solid #ff976a;
  color: #ff976a;
}

.list {
  margin-top: 52px;
  background: #fff;
}
</style>