<template>
  <div class="upload-container">
    <!-- 活动来源 -->
    <van-field 
      v-model="form.source" 
      is-link 
      readonly 
      label="活动来源" 
      placeholder="请选择活动来源" 
      @click="openSourcePicker" 
    />
    <!-- 服务时间 -->
    <van-field 
      v-model="form.date" 
      is-link 
      readonly 
      label="服务时间" 
      placeholder="请选择日期" 
      @click="openDatePicker" 
    />
    <!-- 服务时长 -->
    <van-field 
      v-model="form.duration" 
      is-link 
      readonly 
      label="服务时长" 
      placeholder="请选择时长" 
      @click="openDurationPicker" 
    />
    <!-- 服务内容 -->
    <van-field 
      v-model="form.content" 
      label="服务内容" 
      placeholder="请简要描述" 
      label-align="top" 
      type="textarea" 
      maxlength="100" 
      show-word-limit 
    />
    <!-- 图片上传 -->
    <van-uploader 
      v-model="form.fileList" 
      multiple 
      max-count="2" 
      :upload-text="'添加照片 ' + form.fileList.length + '/2'" 
      style="padding: 10px"
    />
    <!-- 提交按钮 -->
    <van-button 
      type="primary" 
      color="#ff5d23" 
      block 
      @click="submit"
      style="margin-top: 20px"
    >提交</van-button>

    <!-- 活动来源选择器 -->
    <van-popup v-model:show="sourcePickerShow" round position="bottom">
      <van-picker 
        :columns="sourceOptions" 
        @cancel="sourcePickerShow = false" 
        @confirm="handleSourceConfirm" 
      />
    </van-popup>

    <!-- 服务时长选择器 -->
    <van-popup v-model:show="durationPickerShow" round position="bottom">
      <van-picker 
        :columns="durationOptions" 
        @cancel="durationPickerShow = false" 
        @confirm="handleDurationConfirm" 
      />
    </van-popup>

    <!-- 日期选择器 -->
    <van-popup 
      v-model:show="datePickerShow" 
      round 
      position="bottom" 
      :z-index="3000"
    >
      <van-picker
        :columns="dateColumns"
        title="选择日期"
        show-toolbar
        :visible-item-count="7"
        @confirm="handleDateConfirm"
        @cancel="datePickerShow = false"
      />
    </van-popup>
  </div>
</template>

<script>
import { showToast, showSuccessToast, showFailToast } from 'vant';
import axios from 'axios';

console.log('UploadService 组件开始加载');

export default {
  name: 'UploadService',
  mounted() {
    console.log('UploadService 组件已挂载');
    console.log('yearOptions:', this.yearOptions);
    console.log('monthOptions:', this.monthOptions);
    console.log('dayOptions:', this.dayOptions);
    console.log('dateColumns:', this.dateColumns);
  },
  data() {
    const currentYear = new Date().getFullYear();
    const years = [];
    for (let i = currentYear - 5; i <= currentYear + 5; i++) {
      years.push({ text: String(i) });
    }
    const months = [];
    for (let i = 1; i <= 12; i++) {
      months.push({ text: String(i).padStart(2, '0') });
    }
    const days = [];
    for (let i = 1; i <= 31; i++) {
      days.push({ text: String(i).padStart(2, '0') });
    }
    
    return {
      sourcePickerShow: false,
      durationPickerShow: false,
      datePickerShow: false,
      form: {
        source: '',
        date: '',
        duration: '',
        content: '',
        fileList: []
      },
      sourceOptions: [
        { text: '校园志愿活动', value: 1 },
        { text: '社区公益服务', value: 2 },
        { text: '企业合作项目', value: 3 }
      ],
      durationOptions: [
        { text: '1小时', value: 1 },
        { text: '2小时', value: 2 },
        { text: '3小时', value: 3 }
      ],
      yearOptions: years,
      monthOptions: months,
      dayOptions: days
    };
  },
  computed: {
    dateColumns() {
      return [
        this.yearOptions,
        this.monthOptions,
        this.dayOptions
      ];
    }
  },
  methods: {
    openSourcePicker() {
      this.sourcePickerShow = true;
    },
    openDatePicker() {
      this.datePickerShow = true;
    },
    openDurationPicker() {
      this.durationPickerShow = true;
    },
    handleSourceConfirm(selected) {
      this.form.source = selected.selectedOptions[0] ? selected.selectedOptions[0].text : selected.text;
      this.sourcePickerShow = false;
    },
    handleDurationConfirm(selected) {
      this.form.duration = selected.selectedOptions[0] ? selected.selectedOptions[0].text : selected.text;
      this.durationPickerShow = false;
    },
    handleDateConfirm(selected) {
      console.log('日期选择完整参数:', JSON.stringify(selected, null, 2));
      console.log('selectedValues:', selected.selectedValues);
      console.log('selectedOptions:', selected.selectedOptions);
      console.log('text:', selected.text);
      
      // 尝试多种方式获取值
      let year, month, day;
      
      if (selected.selectedOptions && selected.selectedOptions.length >= 3) {
        year = selected.selectedOptions[0]?.text || '';
        month = selected.selectedOptions[1]?.text || '';
        day = selected.selectedOptions[2]?.text || '';
      } else if (selected.selectedValues && selected.selectedValues.length >= 3) {
        year = selected.selectedValues[0]?.text || selected.selectedValues[0] || '';
        month = selected.selectedValues[1]?.text || selected.selectedValues[1] || '';
        day = selected.selectedValues[2]?.text || selected.selectedValues[2] || '';
      } else if (selected.text) {
        // 可能是单个值的情况
        year = selected.text;
      }
      
      this.form.date = year + '-' + month + '-' + day;
      this.datePickerShow = false;
      console.log('最终日期:', this.form.date);
    },
    submit() {
      if (!this.form.source) {
        showToast('请选择活动来源');
        return;
      }
      if (!this.form.date) {
        showToast('请选择服务时间');
        return;
      }
      if (!this.form.duration) {
        showToast('请选择服务时长');
        return;
      }
      if (!this.form.content) {
        showToast('请填写服务内容');
        return;
      }
      if (this.form.fileList.length === 0) {
        showToast('请上传服务照片');
        return;
      }
      
      // 构建提交数据
      const submitData = {
        source: this.form.source,
        date: this.form.date,
        duration: this.form.duration,
        content: this.form.content,
        pics: this.form.fileList.map(file => file.content || file.url || '')
      };
      
      // 调用API提交服务记录
      axios.post('/api/act/uploadService', submitData)
        .then(response => {
          const { error, msg } = response.data;
          if (error === 0) {
            showSuccessToast('提交成功！');
            // 清空表单
            this.form = {
              source: '',
              date: '',
              duration: '',
              content: '',
              fileList: []
            };
          } else {
            showFailToast(msg || '提交失败，请稍后重试');
          }
        })
        .catch(err => {
          console.error('提交服务记录失败：', err);
          showFailToast('网络异常，请稍后重试');
        });
    }
  }
};
</script>

<style scoped>
.upload-container {
  padding: 15px;
  background: #fff;
  min-height: 100vh;
}
</style>
